docker stack rm gwapi
docker stack deploy -c docker-compose.yml gwapi --with-registry-auth