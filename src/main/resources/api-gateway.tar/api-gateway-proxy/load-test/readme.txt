npm install -g artillery
artillery -V
artillery run <yml file>
