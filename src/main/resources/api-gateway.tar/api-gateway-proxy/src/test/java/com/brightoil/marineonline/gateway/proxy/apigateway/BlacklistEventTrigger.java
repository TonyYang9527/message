package com.brightoil.marineonline.gateway.proxy.apigateway;

import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;
import com.brightoil.marineonline.gateway.base.apigateway.model.EventType;
import com.brightoil.marineonline.gateway.base.apigateway.repo.RedisRepoImpl;
import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigServiceImpl;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.util.EventUtil;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;

public class BlacklistEventTrigger extends BaseTest {

    private  static  boolean block = true;

    private static String getBlackListAction() {
        return block ? Constants.EVENT_PARAM_BLACKLIST_ACTION_ADD : Constants.EVENT_PARAM_BLACKLIST_ACTION_RM;
    }

    private static String[] getBlackListIpAddress() {
        return new String[]{
               "192.168.48.132",
                "172.28.208.1",
                "192.168.65.83"

        };
    }

    private static Logger logger = LoggerFactory.getLogger(BlacklistEventTrigger.class);

    public static void main(String []args){
        config();
        ConfigServiceImpl cfg = new ConfigServiceImpl();
        cfg.setLogger(logger);
        cfg.init();

        RedisRepoImpl redisRepo = new RedisRepoImpl();
        redisRepo.setLogger(logger);
        redisRepo.setConfigService(cfg);
        redisRepo.init();

        String channelName = (String)cfg.get(Config.ENV_CHANNEL);

        String[] arrs = getBlackListIpAddress();

        JsonArray arr = new JsonArray();
        Arrays.stream(arrs).forEach(s -> {
            arr.add(s);
        });

        JsonObject data = new JsonObject();
        data.put(Constants.EVENT_PARAM_BLACKLIST_HOST_ADDR, arr);
        data.put(Constants.EVENT_PARAM_BLACKLIST_ACTION, getBlackListAction());

        EventUtil util = new EventUtil();
        util.setEventType(EventType.BLACKLIST);
        util.setData(data);

        redisRepo.getPubConnection(event -> {
            logger.info("sending message {} to channel {}", util.encode(), channelName);
            event.result().async().publish(channelName, util.encode());
        });
    }

}
