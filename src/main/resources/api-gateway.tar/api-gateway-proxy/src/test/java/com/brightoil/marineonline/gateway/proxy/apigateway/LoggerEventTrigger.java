package com.brightoil.marineonline.gateway.proxy.apigateway;

import com.brightoil.marineonline.gateway.proxy.apigateway.service.DefaultConfig;
import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;
import com.brightoil.marineonline.gateway.base.apigateway.model.EventType;
import com.brightoil.marineonline.gateway.base.apigateway.repo.RedisRepoImpl;
import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigServiceImpl;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.util.EventUtil;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;

public class LoggerEventTrigger extends BaseTest {

    private static String getLoggerLevel() {
        return "DEBUG";
    }

    private static String[] getClassName() {
        return new String[]{
            //"com.brightoil.marineonline.apigateway.service.ConfigServiceImpl",
            "HttpRequestHandler",
                //,
            //"ReverseProxy",
            //"com.brightoil.marineonline.apigateway.service.WebClientServiceImpl",
            //"com.brightoil.marineonline.apigateway.filter.filters.UserAuthFilter",
            //"com.brightoil.marineonline.apigateway.service.HttpServiceImpl",
            //"com.brightoil.marineonline.apigateway.service.AnonTokenServiceImpl",
            //"com.brightoil.marineonline.apigateway.service.UUIDService",
            //"com.brightoil.marineonline.apigateway.service.RedisServiceImpl",
            //"com.brightoil.marineonline.apigateway.service.HostServiceImpl",
            //"com.brightoil.marineonline.apigateway.server.ServerImpl",
            //"com.brightoil.marineonline.apigateway.repo.RedisRepoImpl",
                //"com.brightoil.marineonline.apigateway.filter.filters.UserAnonTokenFilter",

            "ReverseProxy",

            "com.brightoil.marineonline.gateway.base.apigateway.server.listener.SelfListenerServiceImpl",
            "com.brightoil.marineonline.gateway.base.apigateway.server.listener.CommonListenerServiceImpl",
            "com.brightoil.marineonline.gateway.proxy.apigateway.service.ChannelEventServiceImpl"
                //,
            //"com.brightoil.marineonline.apigateway.server.ServerServiceImpl",
            //"com.brightoil.marineonline.apigateway.server.ListenerServiceImpl",
            //"com.brightoil.marineonline.apigateway.service.AuthServiceImpl",
            //"com.brightoil.marineonline.apigateway.service.WhitelistServiceImpl"
            //,
            //"com.brightoil.marineonline.apigateway.service.HttpHeaderServiceImpl",
            //"com.brightoil.marineonline.apigateway.filter.filters.WhitelistFilter"
        };
    }

    private static Logger logger = LoggerFactory.getLogger(LoggerEventTrigger.class);

    public static void main(String []args){

        config();
        ConfigServiceImpl cfg = new ConfigServiceImpl();
        cfg.setLogger(logger);
        cfg.setConfig(new DefaultConfig());
        cfg.init();

        RedisRepoImpl redisRepo = new RedisRepoImpl();
        redisRepo.setLogger(logger);
        redisRepo.setConfigService(cfg);
        redisRepo.init();

        String channelName = (String)cfg.get(Config.ENV_CHANNEL);

        String[] arrs = getClassName();

        JsonArray arr = new JsonArray();
        Arrays.stream(arrs).forEach(s -> {
            arr.add(s);
        });

        JsonObject data = new JsonObject();
        data.put(Constants.EVENT_PARAM_LOGGING_CLASS_NAME, arr);
        data.put(Constants.EVENT_PARAM_LOGGING_LEVEL, getLoggerLevel());

        EventUtil util = new EventUtil();
        util.setEventType(EventType.LOGGING);
        util.setData(data);

        redisRepo.getPubConnection(event -> {
            logger.info("sending message {} to channel {}", util.encode(), channelName);
            event.result().async().publish(channelName, util.encode());
        });
    }

}
