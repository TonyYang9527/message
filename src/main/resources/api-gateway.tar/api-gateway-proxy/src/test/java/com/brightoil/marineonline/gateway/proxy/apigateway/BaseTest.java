package com.brightoil.marineonline.gateway.proxy.apigateway;

import com.brightoil.marineonline.gateway.base.apigateway.service.Config;

public class BaseTest {

    protected static String getConfigFile(String fileName) {
        return BaseTest.class.getClassLoader().getResource(fileName).getPath();
    }

    protected static void config(){
        System.setProperty(Config.CONFIG_FILE_LOCAL,    getConfigFile("config.properties"));
        System.setProperty(Config.CONFIG_FILE_GLOBAL,   getConfigFile("env.properties"));
    }
}