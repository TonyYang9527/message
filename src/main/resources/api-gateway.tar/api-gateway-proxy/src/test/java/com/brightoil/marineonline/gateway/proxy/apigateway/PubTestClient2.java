package com.brightoil.marineonline.gateway.proxy.apigateway;

import com.brightoil.marineonline.gateway.base.apigateway.Starter;
import com.brightoil.marineonline.gateway.base.apigateway.service.Config;

public class PubTestClient2 extends BaseTest {

   public static void main(String []args){
       config();
       System.setProperty(Config.CONFIG_FILE_CUSTOME,  getConfigFile("node_2.properties"));
       try {
           Starter bootstrap = new Starter();
           bootstrap.bootstrap();
       } catch (Throwable e) {
           e.printStackTrace();
       }
   }
}