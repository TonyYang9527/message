package com.brightoil.marineonline.gateway.proxy.apigateway;


import com.brightoil.marineonline.gateway.base.apigateway.Starter;
import com.brightoil.marineonline.gateway.base.apigateway.service.Config;

public class PubTestClient1 extends BaseTest {

   public static void main(String []args){
       try {
           config();
           System.setProperty(Config.CONFIG_FILE_CUSTOME,  getConfigFile("node_1.properties"));

           Starter bootstrap = new Starter();
           bootstrap.bootstrap();
       } catch (Throwable e) {
           e.printStackTrace();
       }
   }
}