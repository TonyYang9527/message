package com.brightoil.marineonline.gateway.proxy.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.model.EventType;
import com.brightoil.marineonline.gateway.base.apigateway.service.BlacklistService;
import com.brightoil.marineonline.gateway.base.apigateway.service.ChannelEventAbstractServiceImpl;
import com.brightoil.marineonline.gateway.base.apigateway.service.ChannelEventService;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;

@Singleton
public class ChannelEventServiceImpl extends ChannelEventAbstractServiceImpl implements ChannelEventService {

    @InjectLogger
    Logger logger;

    @Inject
    BlacklistService blacklistService;

    @Override
    protected Logger getLogger() {
        return logger;
    }

    @Override
    protected BlacklistService getBlacklistService() {
        return blacklistService;
    }

    @Override
    protected void handleEvent(EventType eventType, JsonObject event) {}
}
