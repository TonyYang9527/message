package com.brightoil.marineonline.gateway.proxy.apigateway.service;

import com.brightoil.marineonline.gateway.proxy.apigateway.handler.HttpRequestHandler;
import com.brightoil.marineonline.gateway.base.apigateway.handler.WelcomeHandler;
import com.brightoil.marineonline.gateway.base.apigateway.server.ServerService;
import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigService;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;
import org.slf4j.Logger;

@Singleton
public class ServerServiceImpl implements ServerService {

    @InjectLogger
    Logger logger;

    @Inject
    ConfigService configService;

    @Inject
    WelcomeHandler welcomeHandler;

    @Inject
    HttpRequestHandler httpRequestHandler;

    private int serverPort;
    private String routingApiURI;
    private String routingHttpURI;

    @Override
    public void config() {
        try{
            serverPort = (int) configService.get(Config.SERVER_PORT);
            routingApiURI = (String) configService.get(Config.ENV_ROUTING_API);
            routingHttpURI = (String) configService.get(Config.ENV_ROUTING_HTTP);
        }catch (Throwable ex){
            logger.error("init failure due to {}", ex.getMessage(), ex);
        }
    }

    @Override
    public void start(Handler<AsyncResult<Void>> handler) {
        GatewayProxy gateway = new GatewayProxyImpl(serverPort, routingApiURI, routingHttpURI);
        gateway.config(welcomeHandler);
        gateway.config(httpRequestHandler);
        gateway.start();
    }

    @Override
    public void stop(Handler<AsyncResult<Void>> handler) {}
}