package com.brightoil.marineonline.gateway.proxy.apigateway.filter.filters;

import com.brightoil.marineonline.gateway.proxy.apigateway.filter.context.HttpRequest;
import com.brightoil.marineonline.gateway.base.apigateway.filter.Filter;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;
import com.brightoil.marineonline.gateway.base.apigateway.service.HttpHeaderService;
import com.brightoil.marineonline.gateway.base.apigateway.service.HttpResponseService;
import com.brightoil.marineonline.gateway.base.apigateway.service.WebClientService;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.vertx.reactivex.core.MultiMap;
import io.vertx.reactivex.core.http.HttpClient;
import io.vertx.reactivex.core.http.HttpClientRequest;
import io.vertx.reactivex.core.http.HttpServerRequest;
import io.vertx.reactivex.core.http.HttpServerResponse;
import io.vertx.reactivex.core.streams.Pump;
import io.vertx.reactivex.ext.web.MIMEHeader;
import org.slf4j.Logger;

@Singleton
public class ReverseProxy implements Filter<HttpRequest> {

    private static final String CONST_MULTIPART = "multipart";

    @InjectLogger
    Logger logger;

    @Inject
    WebClientService clientService;

    @Inject
    HttpHeaderService headerService;

    @Inject
    HttpResponseService responseService;

    @Override
    public void doFilter(FilterConfig<HttpRequest> cfg) {
        try{
            doRequest(cfg);
        }catch (Throwable e){
            try{
                logger.error("[{}] - proxy failure due to {}", cfg.get().getRequestId(), e.getMessage(), e);
                responseService.response(cfg.get().getRequestId(), cfg.get().request(), cfg.get().response(), HttpResponseStatus.BAD_REQUEST.code(), e);
            }catch (Throwable ex){}
            cfg.stop().doFilter();
        }
    }

    private void doRequest(FilterConfig<HttpRequest> cfg) {

        HttpRequest rtx = cfg.get();

        final HttpServerRequest request = rtx.request();
        final HttpServerResponse response = rtx.response();
        if(response == null){
            cfg.stop().doFilter();
            logger.info("[{}] - proxy stopped due to response is null", cfg.get().getRequestId());
            return;
        }

        MIMEHeader contentType    = rtx.parsedHeader().contentType();
        MultiMap requestHeaders   = request.headers();

        HttpClient httpClient = clientService.getHttpClient();
        final HttpClientRequest proxyRequest = httpClient.request(request.method(), rtx.getServicePort(), rtx.getServiceName(), rtx.getServiceURI(), proxyResponse -> {

            // response handling start
            proxyResponse.pause();
            Pump pumpingResposne = Pump.pump(proxyResponse, response);

            if(response.closed() || response.ended()){
                // check connection close before process
                logger.info("[{}] - http-response-late-closed: {}", rtx.getRequestId());

                // stop ump
                pumpingResposne.stop();
                // reset proxy response
                proxyResponse.endHandler(null);
                proxyResponse.exceptionHandler(null);
                try{proxyResponse.getDelegate().netSocket().close();}catch (Throwable ex){}

                // return http client
                clientService.retHttpClient(httpClient);
                // stop filter
                cfg.stop().doFilter();
                return;
            }

            response.exceptionHandler(null);
            response.exceptionHandler(e -> {
                // client closed connection before proxy request response
                logger.info("[{}] - http-response-err: {}", rtx.getRequestId(), e.getMessage());

                // stop ump
                pumpingResposne.stop();

                // reset proxy response
                proxyResponse.endHandler(null);
                proxyResponse.exceptionHandler(null);
                try{proxyResponse.getDelegate().netSocket().close();}catch (Throwable ex){}

                // return http client
                clientService.retHttpClient(httpClient);

                // close response
                if(!response.ended()){
                    try{response.end();}catch (Throwable ex){logger.info("[{}] - http-response-end-err: {}", rtx.getRequestId(), e.getMessage());}
                }
                if(!response.closed()){
                    try{response.close();}catch (Throwable ex){logger.info("[{}] - http-response-close-err: {}", rtx.getRequestId(), e.getMessage());}
                }
            });

            response.endHandler(e -> {
                logger.info("[{}] - http-response-end, status: {}", rtx.getRequestId(), proxyResponse.statusCode());
                clientService.retHttpClient(httpClient);
                cfg.stop().doFilter();
            });

            proxyResponse.exceptionHandler(e->{
                logger.info("[{}] - proxy-response-err: {}", rtx.getRequestId(), e.getMessage());
            });

            proxyResponse.endHandler(e -> {
                logger.info("[{}] - proxy-response-end, size: {}", rtx.getRequestId(), pumpingResposne.numberPumped());
                responseService.response(rtx.getRequestId(), rtx.request(), rtx.response(), HttpResponseStatus.OK.code());
            });

            if(!(response.closed() || response.ended())) {
                // set response code
                response.setChunked(true).setStatusCode(proxyResponse.statusCode());
            }
            if(!(response.closed() || response.ended())) {
                // copy response headers
                headerService.copyResponseHeader(rtx.getRequestId(), rtx.getAnonToken(), proxyResponse.headers(), response.headers(), true);
            }
            if(!(response.closed() || response.ended())) {
                // config response headers
                headerService.allowResponseHeader(rtx.getRequestId(), requestHeaders, response.headers());
            }
            // resume and start
            pumpingResposne.start();
            proxyResponse.resume();
            // response handling end
        }).setChunked(true);

        request.setExpectMultipart(contentType.isPermitted() && CONST_MULTIPART.equals(contentType.component()));
        headerService.copyRequestHeader(rtx.getRequestId(), rtx.getAnonToken(), requestHeaders, proxyRequest.headers());
        proxyRequest.headers().set(HttpHeaderNames.HOST.toString(), rtx.getServiceName());

        Pump pump = Pump.pump(request, proxyRequest);

        proxyRequest.exceptionHandler(e -> {
            logger.info("[{}] - proxy-request-err: {}", rtx.getRequestId(), e.getMessage());
            pump.stop();
            response.exceptionHandler(null);
            responseService.response(rtx.getRequestId(), rtx.request(), rtx.response(), HttpResponseStatus.SERVICE_UNAVAILABLE.code());
            cfg.stop().doFilter();
        });

        request.endHandler(e -> {
            logger.info("[{}] - http-request-end", rtx.getRequestId());
            request.exceptionHandler(null);
            pump.stop();
            try{ proxyRequest.end(); }catch (Throwable ex){}
        });

        if(response.closed() || response.ended()){
            logger.info("[{}] - http-response-prior-closed: {}", rtx.getRequestId());
            cfg.get().resumeRequest();
            pump.stop();
            proxyRequest.exceptionHandler(null);
            try{ proxyRequest.reset(); }catch (Throwable ex){}
            try{ proxyRequest.end(); }catch (Throwable ex){}
            // return http client
            clientService.retHttpClient(httpClient);
            // stop filter
            cfg.stop().doFilter();
            return;
        }

        response.exceptionHandler(e -> {
            // client closed connection before proxy request response
            logger.info("[{}] - http-response-prior-err: {}", rtx.getRequestId(), e.getMessage());
            // stop ump
            pump.stop();
            // reset proxy request
            proxyRequest.exceptionHandler(null);
            try{ proxyRequest.reset(); }catch (Throwable ex){}
            try{ proxyRequest.end(); }catch (Throwable ex){}
            // close response
            if(!response.ended()){
                try{response.end();}catch (Throwable ex){logger.info("[{}] - http-response-prior-end-err: {}", rtx.getRequestId(), e.getMessage());}
            }
            if(!response.closed()){
                try{response.close();}catch (Throwable ex){logger.info("[{}] - http-response-prior-close-err: {}", rtx.getRequestId(), e.getMessage());}
            }
            // return http client
            clientService.retHttpClient(httpClient);
            // stop filter
            cfg.stop().doFilter();
        });

        cfg.get().resumeRequest();
        pump.start();
    }
}
