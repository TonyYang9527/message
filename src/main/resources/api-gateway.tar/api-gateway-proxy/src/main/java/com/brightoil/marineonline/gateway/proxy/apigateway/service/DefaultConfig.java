package com.brightoil.marineonline.gateway.proxy.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.model.ConfigType;
import com.brightoil.marineonline.gateway.base.apigateway.model.Property;
import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.guicetools.scan.Order;
import com.google.inject.Singleton;

@Singleton
@Order(0)
public class DefaultConfig implements Config {

    private Property[] defaultProps;

    private Property[] localProps;

    public DefaultConfig(){
        defaultProps = new Property[]{
                Property.create(ENV,                       ConfigType.STRING),
                Property.create(SERVER_PORT,               ConfigType.INT),
                Property.create(REDIS_IPS,                 ConfigType.STRING),
                Property.create(REDIS_PORTS,               ConfigType.STRING)
        };


        localProps = new Property[]{
                Property.create(ENV_CHANNEL,                          ConfigType.STRING),
                Property.create(ENV_GUEST_TOKEN,                      ConfigType.STRING),
                Property.create(ENV_AUTH,                             ConfigType.STRING),
                Property.create(ENV_AUTH_ENABLED,                     ConfigType.STRING),
                Property.create(ENV_WHITELIST_URI,                    ConfigType.STRING),
                Property.create(ENV_WHITELIST_FREQUENCY,              ConfigType.INT),
                Property.create(ENV_ROUTING_API,                      ConfigType.STRING),
                Property.create(ENV_ROUTING_HTTP,                     ConfigType.STRING),
                Property.create(REDIS_TIMEOUT,                        ConfigType.INT),
                Property.create(REDIS_DATABASE,                       ConfigType.INT),
                Property.create(REDIS_MASTER_ID,                      ConfigType.STRING),
                Property.create(ENV_COMMON_LISTENER,                  ConfigType.STRING),
                Property.create(ENV_SELF_LISTENER,                    ConfigType.STRING),
                Property.create(JWT_ENCRYPT_KEY,                      ConfigType.STRING)
        };
    }

    @Override
    public Property[] getDefaultProperties() {
        return defaultProps;
    }

    @Override
    public Property[] getLocalProperties() {
        return localProps;
    }
}
