package com.brightoil.marineonline.gateway.proxy.apigateway.filter.context;

import com.brightoil.marineonline.gateway.base.apigateway.filter.context.Security;
import io.vertx.reactivex.core.http.HttpServerRequest;
import io.vertx.reactivex.core.http.HttpServerResponse;
import io.vertx.reactivex.ext.web.ParsedHeaderValues;
import io.vertx.reactivex.ext.web.RoutingContext;

public interface HttpRequest extends Security {

    void                setCtx(RoutingContext ctx);
    RoutingContext      getCtx();
    ParsedHeaderValues  parsedHeader();
    HttpServerResponse  response();
    HttpServerRequest   request();

    HttpRequest        pauseRequest();
    HttpRequest        resumeRequest();
}
