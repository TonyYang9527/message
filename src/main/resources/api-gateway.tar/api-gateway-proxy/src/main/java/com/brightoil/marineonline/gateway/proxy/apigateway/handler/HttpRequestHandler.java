package com.brightoil.marineonline.gateway.proxy.apigateway.handler;

import com.brightoil.marineonline.gateway.proxy.apigateway.common.Constants;
import com.brightoil.marineonline.gateway.proxy.apigateway.filter.context.HttpRequest;
import com.brightoil.marineonline.gateway.proxy.apigateway.service.GatewayCacheService;
import com.brightoil.marineonline.gateway.base.apigateway.filter.Delegate;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterChain;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfigCallback;
import com.brightoil.marineonline.gateway.base.apigateway.handler.WelcomeHandler;
import com.brightoil.marineonline.gateway.base.apigateway.model.FilterType;
import com.brightoil.marineonline.gateway.base.apigateway.service.*;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.util.HttpTokenUtil;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.jsonwebtoken.*;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.vertx.core.Handler;
import io.vertx.reactivex.core.http.HttpServerRequest;
import io.vertx.reactivex.ext.web.RoutingContext;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

@Singleton
public class HttpRequestHandler implements Handler<RoutingContext>, FilterConfigCallback {

    @InjectLogger
    Logger logger;

    @Inject
    GatewayCacheService cacheService;

    @Inject
    UUIDService uuidService;

    @Inject
    WelcomeHandler welcomeHandler;

    @Inject
    BlacklistService blacklistService;

    @Inject
    HttpHeaderService headerService;

    @Inject
    HttpResponseService responseService;

    @Inject
    FilterChainService filterChainService;

    @Inject
    HostService hostService;

    FilterChain filterChain;

    public void config(){
        filterChain = filterChainService.getFilterChain(FilterType.HTTP);
    }

    @Override
    public <T extends Delegate> void release(FilterConfig<T> filterConfig) {
        cacheService.releaseHttpRequestFilterConfig(filterConfig);
    }

    @Override
    public void handle(RoutingContext ctx) {
        String uuid = null;
        try{
            uuid = uuidService.getUniqueRequestId();
            proxy(uuid, ctx);
        }catch (Throwable ex){
            logger.info("[{}] - quick respond for failed request", uuid, ex);
            ctx.request().resume();
            responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.BAD_REQUEST.code(), ex);
        }
    }

    public void proxy(String uuid, RoutingContext ctx) {
        /**
         * 1. generate request unique id
         */
        String host = null;
        HttpServerRequest request = ctx.request();
        try {
            host = headerService.getRemoteHost(ctx);
            if (blacklistService.check(uuid, host)) {
                responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.FORBIDDEN.code());
                return;
            }
        }catch (Throwable ex){
            logger.error("[{}] - [{}] - request blocked due to {}", uuid, host, ex.getMessage());
            responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.FORBIDDEN.code(), ex);
            return;
        }
        /**
         * 2. check for head request or option request
         */
        if (HttpMethod.OPTIONS.name().equalsIgnoreCase(request.method().name()) || HttpMethod.HEAD.name().equalsIgnoreCase(request.method().name())) {
            responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.OK.code());
            return;
        }

        /**
         * 3. check uri requirement
         */
        String uri = request.uri();
        if (uri == null || uri.length() < 6) {
            welcomeHandler.handle(ctx);
            return;
        }
        uri = uri.trim();
        if (uri.endsWith("/favicon.ico")) {
            responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.OK.code());
            return;
        }
        if (!uri.startsWith("/api/")) {
            logger.info("[{}] - quick respond for invalid request", uuid);
            responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.BAD_REQUEST.code());
            return;
        }
        /**
         * 4. check token validity and retrieve user id from token
         */
        String token = null;
        String userId = null;
        boolean isGuest = false;
        try{
            token = request.headers().get(Constants.HEADER_PROPERTY_HTTP_USER_TOKEN);
        }catch (Throwable ex){
            logger.info("[{}] - retrieve token error {}", uuid, ex.getMessage(), ex);
        }
        if(StringUtils.isNotBlank(token)){
            Claims claims = null;
            String parseToken = null;
            try {
                isGuest = HttpTokenUtil.isGuestToken(parseToken);
            }catch (Throwable ex){
                logger.info("[{}] - quick respond for token <invalid token> {} ", uuid, ex.getMessage());
                responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.FORBIDDEN.code(), ex);
                return;
            }
            try{
                parseToken = HttpTokenUtil.parseToken(token);
                claims = HttpTokenUtil.getToken(parseToken);
            }catch (SignatureException ex1){
                logger.info("[{}] - quick respond for token <invalid token signature> {} ", uuid, ex1.getMessage());
                responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.FORBIDDEN.code(), ex1);
                return;
            }catch (MalformedJwtException ex2){
                logger.info("[{}] - quick respond for token <malformed token> {} ", uuid, ex2.getMessage());
                responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.FORBIDDEN.code(), ex2);
                return;
            }catch (ExpiredJwtException ex3){
                if(isGuest){
                    // clear token to retrieve a new token to proceed the request
                    token = null;
                }else{
                    logger.info("[{}] - quick respond for token <token expired> {} ", uuid, ex3.getMessage());
                    responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.FORBIDDEN.code(), ex3);
                    return;
                }
            }catch (Exception ex){
                logger.info("[{}] - quick respond for token <unknown token error> {} ", uuid, ex.getMessage());
                responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.FORBIDDEN.code(), ex);
                return;
            }
            try {
                if(claims != null){
                    userId = claims.getSubject();
                }
            }catch (Throwable ex){
                logger.error("[{}] - quick respond for token <getting subject from token failed> {}", uuid, ex.getMessage());
                if(isGuest){
                    userId = null;
                }else{
                    responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.FORBIDDEN.code(), ex);
                    return;
                }
            }
        }

        FilterConfig<HttpRequest> filterConfig = cacheService.borrowHttpRequestFilterConfig(filterChain, this);

        HttpRequest var = filterConfig.get();
        var.setAuthToken(null);
        var.setGuestToken(false);

        // populate variables
        if (!populateFilterVariable(uuid, var, uri)) {
            logger.error("[{}] - quick respond for invalid request", uuid);
            responseService.response(uuid, ctx.request(), ctx.response(), HttpResponseStatus.BAD_REQUEST.code());
            return;
        }

        var.setCtx(ctx);
        var.setRequestId(uuid);

        var.setUserId(userId);
        var.setGuestToken(isGuest);
        if(StringUtils.isNotBlank(token)) {
            var.setAuthToken(token);
        }

        // start filter chain
        var.pauseRequest();

        // default to authentication required for all resources
        var.setAuthRequired(true);

        // tracking variables
        request.headers().set(Constants.HEADER_PROPERTY_HTTP_REQUEST_KEY, uuid);
        request.headers().set(Constants.HEADER_PROPERTY_HTTP_GATEWAY, hostService.getHostAddr());

        logger.info("[{}] - [{}] - [{}]", uuid, host, uri);

        filterChain.doFilter(filterConfig);
    }

    private boolean populateFilterVariable(String ref, HttpRequest var, String uri) {
        try{
            /**
             * URL format: /api/<service name>:<port number>/<service uri>
             */
            uri = uri.replace(Constants.REQUEST_URI_DOUBLE_SLASH, Constants.REQUEST_URI_SINGLE_SLASH);
            String reqURI   = uri.substring(5);
            int    slash    = reqURI.indexOf("/");
            if(slash == -1){
                /**
                 * for URL like : /api/<service name>:<port number>
                 */
                reqURI      = reqURI.concat("/");
                slash       = reqURI.indexOf("/");
            }
            String proxySrv = slash != -1 ? reqURI.substring(0, slash) : null;
            if(proxySrv == null){
                return false;
            }
            String proxyUri = slash != -1 ? reqURI.substring(slash): null;
            int    colonIdx = proxySrv.indexOf(":");
            String srvName  = colonIdx != -1 ? proxySrv.substring(0, colonIdx) : proxySrv;
            String portStr  = colonIdx != -1 ? proxySrv.substring(colonIdx+1) : "";
            int    portNum  = portStr != null && portStr.trim().length() > 0 ? Integer.parseInt(portStr) : 80;

            var.setServiceName(srvName);
            var.setServicePort(portNum);
            var.setServiceURI(proxyUri);
        }catch (Throwable ex){
            logger.error("[{}] - invalid uri {}", ref, uri, ex);
            return false;
        }
        return true;
    }
}
