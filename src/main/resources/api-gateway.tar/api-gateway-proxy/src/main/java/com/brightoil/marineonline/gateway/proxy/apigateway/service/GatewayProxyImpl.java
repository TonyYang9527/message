package com.brightoil.marineonline.gateway.proxy.apigateway.service;

import com.brightoil.marineonline.gateway.proxy.apigateway.handler.HttpRequestHandler;
import com.brightoil.marineonline.gateway.base.apigateway.Gateway;
import com.brightoil.marineonline.gateway.base.apigateway.handler.WelcomeHandler;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import io.vertx.core.http.HttpServerOptions;
import io.vertx.reactivex.core.http.HttpServer;
import io.vertx.reactivex.ext.web.Router;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GatewayProxyImpl implements GatewayProxy {

    private static final Logger logger = LoggerFactory.getLogger(GatewayProxyImpl.class);

    private int serverPort;
    private String routingApiURI;
    private String routingHttpURI;
    private WelcomeHandler welcomeHandler;
    private HttpRequestHandler httpRequestHandler;

    private Router router;
    private HttpServer server;

    public GatewayProxyImpl(int serverPort, String routingApiURI, String routingHttpURI) {
        this.serverPort = serverPort;
        this.routingApiURI = routingApiURI;
        this.routingHttpURI = routingHttpURI;
    }

    @Override
    public void config(WelcomeHandler welcomeHandler) {
        this.welcomeHandler = welcomeHandler;
    }

    @Override
    public void config(HttpRequestHandler httpRequestHandler) {
        this.httpRequestHandler = httpRequestHandler;
    }

    @Override
    public void start() {
        routing();
        server();
    }

    private void routing() {
        router = Router.router(VertxHolder.get());
        router.route(routingApiURI)
                /**.handler(logging)**/
                .handler(welcomeHandler);
        router.route(routingHttpURI)
                /**.handler(logging)**/
                .handler(httpRequestHandler);
    }

    private HttpServerOptions getHttpServerOptions() {
        HttpServerOptions options = new HttpServerOptions();
        options.setCompressionSupported(Gateway.HttpServerOptions_CompressionSupported);
        options.setLogActivity(Gateway.HttpServerOptions_LogActivity);
        options.setTcpKeepAlive(Gateway.HttpServerOptions_TcpKeepAlive);
        // to cater for web socket timeout limit 35 seconds
        options.setIdleTimeout(Gateway.HttpServerOptions_IdleTimeout);
        return options;
    }

    private void server() {
        server = VertxHolder.get().createHttpServer(getHttpServerOptions());
        server.requestHandler(router::accept);
        server.exceptionHandler(event -> {
            logger.error("http server exception {}", event.getMessage(), event);
        });
        server.rxListen(serverPort).subscribe(server -> {
            logger.info("startup server succeed");
        }, e -> {
            logger.error("startup server failure due to {}", e.getMessage(), e);
        });
    }
}
