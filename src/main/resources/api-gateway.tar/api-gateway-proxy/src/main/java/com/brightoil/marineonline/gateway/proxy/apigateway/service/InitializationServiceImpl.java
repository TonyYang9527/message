package com.brightoil.marineonline.gateway.proxy.apigateway.service;

import com.brightoil.marineonline.gateway.proxy.apigateway.handler.HttpRequestHandler;
import com.brightoil.marineonline.gateway.base.apigateway.server.ServerService;
import com.brightoil.marineonline.gateway.base.apigateway.service.FilterChainService;
import com.brightoil.marineonline.gateway.base.apigateway.service.InitializationService;
import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
public class InitializationServiceImpl implements InitializationService {

    @Inject
    FilterChainService filterChainService;

    @Inject
    ServerService serverService;

    @Inject
    HttpRequestHandler httpRequestHandler;

    @Override
    public void init() {
        httpRequestHandler.config();
        serverService.config();
        filterChainService.config();
    }
}
