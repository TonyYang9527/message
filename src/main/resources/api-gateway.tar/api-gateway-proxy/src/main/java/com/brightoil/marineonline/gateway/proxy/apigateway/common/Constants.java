package com.brightoil.marineonline.gateway.proxy.apigateway.common;

public class Constants {

    public static final String HEADER_PROPERTY_HTTP_GATEWAY = com.brightoil.marineonline.gateway.base.apigateway.common.Constants.HEADER_PROPERTY_HTTP_GATEWAY;
    public static final String HEADER_PROPERTY_HTTP_USER_TOKEN = com.brightoil.marineonline.gateway.base.apigateway.common.Constants.HEADER_PROPERTY_HTTP_USER_TOKEN;
    public static final String HEADER_PROPERTY_HTTP_REQUEST_KEY = com.brightoil.marineonline.gateway.base.apigateway.common.Constants.HEADER_PROPERTY_HTTP_REQUEST_KEY;

    public static final String REQUEST_URI_DOUBLE_SLASH = "//";
    public static final String REQUEST_URI_SINGLE_SLASH = "/";


}
