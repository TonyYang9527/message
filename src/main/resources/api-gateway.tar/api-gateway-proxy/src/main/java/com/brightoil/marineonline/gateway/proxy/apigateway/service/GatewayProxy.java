package com.brightoil.marineonline.gateway.proxy.apigateway.service;

import com.brightoil.marineonline.gateway.proxy.apigateway.handler.HttpRequestHandler;
import com.brightoil.marineonline.gateway.base.apigateway.handler.WelcomeHandler;

public interface GatewayProxy {
    void start();
    void config(WelcomeHandler welcomeHandler);
    void config(HttpRequestHandler httpRequestHandler);

}
