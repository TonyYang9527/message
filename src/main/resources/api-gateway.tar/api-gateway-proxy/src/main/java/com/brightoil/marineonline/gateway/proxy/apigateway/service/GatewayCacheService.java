package com.brightoil.marineonline.gateway.proxy.apigateway.service;


import com.brightoil.marineonline.gateway.proxy.apigateway.filter.context.HttpRequest;
import com.brightoil.marineonline.gateway.base.apigateway.filter.Delegate;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterChain;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfigCallback;
import com.brightoil.marineonline.gateway.base.apigateway.service.CacheService;

public interface GatewayCacheService extends CacheService {

    public FilterConfig<HttpRequest> borrowHttpRequestFilterConfig(FilterChain chain, FilterConfigCallback callback);

    public <T extends Delegate> void releaseHttpRequestFilterConfig(FilterConfig<T> filterConfig);
}
