package com.brightoil.marineonline.gateway.proxy.apigateway;


import com.brightoil.marineonline.gateway.base.apigateway.Starter;

public class Bootstrap {

    public static void main(String []args){
        Starter starter = new Starter();
        starter.bootstrap();
    }

}
