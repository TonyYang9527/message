package com.brightoil.marineonline.gateway.proxy.apigateway.service;

import com.brightoil.marineonline.gateway.proxy.apigateway.filter.filters.ReverseProxy;
import com.brightoil.marineonline.gateway.base.apigateway.filter.Filter;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterChain;
import com.brightoil.marineonline.gateway.base.apigateway.filter.filters.UserAnonTokenFilter;
import com.brightoil.marineonline.gateway.base.apigateway.filter.filters.UserAuthFilter;
import com.brightoil.marineonline.gateway.base.apigateway.filter.filters.WhitelistFilter;
import com.brightoil.marineonline.gateway.base.apigateway.model.FilterType;
import com.brightoil.marineonline.gateway.base.apigateway.service.FilterChainService;
import com.google.inject.Inject;
import com.google.inject.Singleton;

@Singleton
public class FilterChainServiceImpl implements FilterChainService {

    @Inject
    private UserAuthFilter authFilter;
    @Inject
    private WhitelistFilter whitelistFilter;
    @Inject
    private UserAnonTokenFilter gustTokenFilter;
    @Inject
    private ReverseProxy reverseProxy;

    @Override
    public void config() {}

    @Override
    public FilterChain getFilterChain(FilterType type) {
        Filter[] filters = null;
        FilterChain chain = null;
        switch (type){
            case HTTP:
                filters = new Filter[]{ whitelistFilter, gustTokenFilter, authFilter, reverseProxy };
                chain = new FilterChain(type.name(), filters);
                break;
        }
        return chain;
    }
}
