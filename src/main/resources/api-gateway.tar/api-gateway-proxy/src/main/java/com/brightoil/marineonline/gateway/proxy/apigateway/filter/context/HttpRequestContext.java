package com.brightoil.marineonline.gateway.proxy.apigateway.filter.context;

import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;
import com.brightoil.marineonline.gateway.base.apigateway.filter.context.SecurityContext;
import com.brightoil.marineonline.gateway.base.apigateway.service.HttpResponseService;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.vertx.reactivex.core.http.HttpServerRequest;
import io.vertx.reactivex.core.http.HttpServerResponse;
import io.vertx.reactivex.ext.web.ParsedHeaderValues;
import io.vertx.reactivex.ext.web.RoutingContext;

public class HttpRequestContext extends SecurityContext implements HttpRequest {

    private HttpResponseService responseService;
    private RoutingContext  ctx;
    private boolean resumed;

    public HttpRequestContext(HttpResponseService headerService){
        this.responseService = headerService;
    }

    @Override
    public HttpRequest pauseRequest() {
        resumed = false;
        if(ctx != null && ctx.request() != null){
            ctx.request().pause();
        }
        return this;
    }

    @Override
    public HttpRequest resumeRequest() {
        if(!resumed){
            if(ctx != null && ctx.request() != null){
                ctx.request().resume();
            }
            resumed = true;
        }
        return this;
    }

    @Override
    public FilterConfig reset() {
        setCtx(null);
        setRequestId(null);
        return super.reset();
    }

    public void setCtx(RoutingContext ctx) {
        this.ctx = ctx;
    }

    @Override
    public RoutingContext getCtx() { return ctx; }

    @Override
    public ParsedHeaderValues parsedHeader() {
        return ctx.parsedHeaders();
    }

    @Override
    public HttpServerResponse response() {
        if(ctx == null){
            return null;
        }
        return ctx.response();
    }

    @Override
    public HttpServerRequest request() {
        if(ctx == null){
            return null;
        }
        return ctx.request();
    }

    public FilterConfig response(int status, Throwable e) {
        if(ctx == null || ctx.response() == null){
            return filterConfig;
        }
        try{
            responseService.response(requestId, ctx.request(), ctx.response(), status, e);
        }catch (Throwable ex){
            try{
                ctx.response().setChunked(true).setStatusCode(HttpResponseStatus.BAD_REQUEST.code()).end();
            }catch (Throwable ex2){}
        }
        return filterConfig;
    }
}
