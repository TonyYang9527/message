package com.brightoil.marineonline.gateway.proxy.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.filter.Delegate;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterChain;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfigCallback;
import com.brightoil.marineonline.gateway.base.apigateway.service.CacheServiceBaseImpl;
import com.brightoil.marineonline.gateway.base.apigateway.service.HttpResponseService;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.proxy.apigateway.filter.context.HttpRequest;
import com.brightoil.marineonline.gateway.proxy.apigateway.filter.context.HttpRequestContext;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import org.slf4j.Logger;

import java.util.concurrent.ConcurrentLinkedQueue;

@Singleton
public class GatewayCacheServiceImpl extends CacheServiceBaseImpl implements GatewayCacheService {

    @InjectLogger
    Logger logger;

    @Inject
    HttpResponseService responseService;

    @Override
    protected void viewCacheDetails() {
        logger.info("http request pool size: {}", a.size());
    }

    private ConcurrentLinkedQueue<FilterConfig<HttpRequest>> a = new ConcurrentLinkedQueue<>();

    @Override
    public FilterConfig<HttpRequest> borrowHttpRequestFilterConfig(FilterChain chain, FilterConfigCallback callback) {
        FilterConfig<HttpRequest> filterConfig = a.poll();
        if(filterConfig == null){
            HttpRequest filterContext = new HttpRequestContext(responseService);
            filterConfig = new FilterConfig<>(filterContext, chain, callback);
        }
        filterConfig.reset();
        return filterConfig;
    }

    @Override
    public <T extends Delegate> void releaseHttpRequestFilterConfig(FilterConfig<T> filterConfig) {
       filterConfig.reset();
       a.add((FilterConfig<HttpRequest>) filterConfig);
    }
}
