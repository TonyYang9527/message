package com.brightoil.marineonline.gateway.base.apigateway.utilities.util;

import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.vertx.core.json.JsonObject;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.util.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.DatatypeConverter;
import java.net.URLDecoder;

public class HttpTokenUtil {

    private static final Logger logger = LoggerFactory.getLogger(HttpTokenUtil.class);

    private static byte[] decoded = null;

    public static void setJwtKey(String key){
        decoded = DatatypeConverter.parseBase64Binary(key);
    }

    public static String parseToken(String token){
        try{
            if(StringUtils.isBlank(token)){
                return null;
            }
            token = URLDecoder.decode(token, "UTF-8");
            int space = token.indexOf(" ");
            if(space != -1){
                token = token.substring(space + 1);
            }
            return token;
        }catch (Exception ex){
            logger.error("invalid request token {} due to {}", token, ex.getMessage());
        }
        return null;
    }

    public static boolean isGuestToken(String token){
        if(StringUtils.isBlank(token)){
            return false;
        }
        try{
            int dotIdx = -1;
            dotIdx = token.indexOf(".");
            token  = token.substring(dotIdx + 1);
            dotIdx = token.indexOf(".");
            token  = token.substring(0, dotIdx);
            JsonObject jwt = new JsonObject(new String(Base64.decodeBase64(token)));
            return jwt.getBoolean(Constants.JWT_TOKEN_GUEST);
        }catch (Throwable ex){
            logger.error("invalid request token {} due to {}", token, ex.getMessage());
        }
        return false;
    }

    public static Claims getToken(String jwt) {
        return Jwts.parser().setSigningKey(decoded).parseClaimsJws(jwt).getBody();
    }
}
