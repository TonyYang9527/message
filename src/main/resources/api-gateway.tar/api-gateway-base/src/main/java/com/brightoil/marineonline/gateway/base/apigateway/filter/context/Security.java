package com.brightoil.marineonline.gateway.base.apigateway.filter.context;

import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;

public interface Security extends Common {

    FilterConfig    setAuthRequired(boolean auth);
    boolean         isAuthRequired();
    FilterConfig    setGuestToken(boolean auth);
    boolean         isGuestToken();
    String          getAuthToken();
    FilterConfig    setAuthToken(String token);
    String          getAnonToken();
    FilterConfig    setAnonToken(String token);
    String          getUserId();
    void            setUserId(String userId);
    FilterConfig    response(int status, Throwable e);
}
