package com.brightoil.marineonline.gateway.base.apigateway.service;

public interface BlacklistService {
    boolean hasHost(String host);

    void addHost(String host);

    void removedHost(String host);

    boolean check(String uuid, String host);
}
