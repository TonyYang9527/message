package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.parser.RequestUrlParser;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.parser.RequestUrlParser;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.reactivex.core.buffer.Buffer;
import io.vertx.reactivex.ext.web.client.HttpResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

@Singleton
public class AnonTokenServiceImpl implements AnonTokenService {

    @InjectLogger
    Logger logger;

    @Inject
    ConfigService configService;

    @Inject
    private HttpService httpUtil;

    private int         port;
    private String      host;
    private String      path;

    public boolean init(){
        try{
            String uri      = (String) configService.get(Config.ENV_GUEST_TOKEN);
            RequestUrlParser parse = new RequestUrlParser(uri);
            this.host       = parse.getHost();
            this.port       = parse.getPort();
            this.path       = parse.getPath();
        }catch (Throwable ex){
            logger.error("init failure due to {}", ex.getMessage(), ex);
            return false;
        }
        return true;
    }

    @Override
    public void createGuestToken(String reqId, Handler<AsyncResult<String>> completer) {
        try {
            httpUtil.doGet(reqId, null, null, host, port, path, null, event -> {
                if (event.cause() != null) {
                    completer.handle(Future.failedFuture(event.cause()));
                    return;
                }
                HttpResponse<Buffer> response = event.result();
                if (response == null) {
                    completer.handle(Future.succeededFuture());
                    return;
                }
                if(HttpResponseStatus.OK.code() != response.statusCode()){
                    completer.handle(Future.succeededFuture());
                    return;
                }
                String token = response.headers().get(Constants.HEADER_PROPERTY_HTTP_USER_TOKEN);
                if(StringUtils.isBlank(token)){
                    completer.handle(Future.succeededFuture());
                    return;
                }
                completer.handle(Future.succeededFuture(token));
            });
        }catch (Throwable ex){
            completer.handle(Future.failedFuture(ex));
        }
    }
}