package com.brightoil.marineonline.gateway.base.apigateway.server.listener;

import com.brightoil.marineonline.gateway.base.apigateway.server.ListenerService;

public interface CommonListenerService extends ListenerService {
}
