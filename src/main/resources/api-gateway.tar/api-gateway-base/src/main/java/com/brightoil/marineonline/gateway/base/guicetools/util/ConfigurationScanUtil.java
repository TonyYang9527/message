package com.brightoil.marineonline.gateway.base.guicetools.util;

import com.brightoil.marineonline.gateway.base.guicetools.scan.Order;
import com.google.common.collect.Sets;
import com.google.inject.Module;
import com.talanlabs.java.lambda.Try;
import org.reflections.Reflections;

import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Set;

public class ConfigurationScanUtil {

    public static Try<List<Module>> list;

    public static void configure(String packageName, final Class<? extends Annotation>... installAnnotationArray) {
        Set<Class<? extends Annotation>> installAnnotations = Sets.newHashSet(installAnnotationArray);
        Reflections packageReflections = new Reflections(packageName);
        Try<List<Module>> ms = installAnnotations.stream().map(packageReflections::getTypesAnnotatedWith).flatMap(Set::stream).filter(Module.class::isAssignableFrom).sorted(ConfigurationScanUtil::orderClass)
                .map(Try.lazyOf(Class::newInstance)).map(Try.lazyOf(o -> (Module) o.get().getOrThrow())).collect(Try.collect());
        try {
            list = ms;
        } catch (Exception e) {
            throw new IllegalStateException("Failed to install module", e);
        }
    }

    private static int orderClass(Class<?> a, Class<?> b) {
        int va = a.isAnnotationPresent(Order.class) ? a.getAnnotation(Order.class).value() : Integer.MAX_VALUE;
        int vb = b.isAnnotationPresent(Order.class) ? b.getAnnotation(Order.class).value() : Integer.MAX_VALUE;
        return Integer.compare(va, vb);
    }
}