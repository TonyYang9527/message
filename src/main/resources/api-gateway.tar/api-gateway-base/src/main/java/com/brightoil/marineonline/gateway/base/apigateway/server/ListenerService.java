package com.brightoil.marineonline.gateway.base.apigateway.server;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

public interface ListenerService {

    void registerListener(Handler<AsyncResult<Void>> completer);
}
