package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import io.vertx.reactivex.core.Vertx;

public abstract class CacheServiceBaseImpl implements CacheService {

    private static final int DEF_TIME = 300000;

    Vertx vertx;

    public boolean init(){
        vertx = VertxHolder.get();
        logging();
        return true;
    }

    private void logging() {
        vertx.setTimer(DEF_TIME, event -> {
            try{
                viewCacheDetails();
            }catch (Throwable ex){}
            logging();
        });
    }

    protected abstract void viewCacheDetails();
}
