package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.vertx.reactivex.core.http.HttpServerRequest;
import io.vertx.reactivex.core.http.HttpServerResponse;

import java.io.PrintWriter;
import java.io.StringWriter;

@Singleton
public class HttpResponseServiceImpl implements HttpResponseService {

    @Inject
    HttpHeaderService headerService;

    @Override
    public void response(String reqId, HttpServerRequest req, HttpServerResponse res, int status) {
        response(reqId, req, res, status, null);
    }

    @Override
    public void response(String reqId, HttpServerRequest req, HttpServerResponse res, int code, Throwable e) {
        if(res == null){
            return;
        }
        if(res.closed()){
            return;
        }
        if(res.ended()){
            return;
        }
        if(req != null){
            req.resume();
        }
        if(res.closed()){
            return;
        }
        if(res.ended()){
            return;
        }
        try {
            res.setChunked(true).setStatusCode(code);
            if ((!res.ended()) && (!res.closed())) {
                headerService.allowResponseHeader(reqId, res.headers());
                if(res != null && e != null) {
                    headerService.copyErrorResponseHeader(res);
                    headerService.allowResponseHeader(reqId, res.headers());
                    responseExceptionDetails(res, e);
                }
                if(!res.ended()){
                    try{
                        res.end();
                    }catch (Throwable ex1){}
                }
                if(!res.closed()){
                    try{
                        res.close();
                    }catch (Throwable ex1){}
                }
            }
        }catch (Throwable ex){
            try {
                if(!res.ended()){
                    try{
                        res.end();
                    }catch (Throwable ex1){}
                }
                if(!res.closed()){
                    try{
                        res.close();
                    }catch (Throwable ex1){}
                }
            }catch (Throwable ex2){}
        }
    }

    private void responseExceptionDetails(HttpServerResponse res, Throwable e) {
        if(res != null && e != null){
            if(!(res.ended() || res.closed())) {
                StringWriter stringWriter = new StringWriter();
                PrintWriter printWriter = new PrintWriter(stringWriter);
                e.printStackTrace(printWriter);
                if (!(res.ended() || res.closed())) {
                    res.setChunked(true).write(stringWriter.toString());
                }
                stringWriter = null;
                printWriter  = null;
            }
            e = null;
        }
    }
}
