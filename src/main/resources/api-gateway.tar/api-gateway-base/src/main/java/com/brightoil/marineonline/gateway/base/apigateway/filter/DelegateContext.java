package com.brightoil.marineonline.gateway.base.apigateway.filter;

public abstract class DelegateContext implements Delegate {

    protected String requestId;
    protected FilterConfig filterConfig;

    public FilterConfig init(FilterConfig filterConfig) {
        this.filterConfig = filterConfig;
        return filterConfig;
    }

    public FilterConfig reset() {
        return filterConfig;
    }

    public FilterConfig filterConfig() {
        return filterConfig;
    }

    public FilterConfig setRequestId(String requestId) {
        this.requestId = requestId;
        return filterConfig;
    }

    public String getRequestId() {
        return requestId;
    }

}
