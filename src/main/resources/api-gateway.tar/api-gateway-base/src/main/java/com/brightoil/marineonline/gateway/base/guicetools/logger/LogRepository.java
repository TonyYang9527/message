package com.brightoil.marineonline.gateway.base.guicetools.logger;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.event.Level;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;

public class LogRepository {

    private static Semaphore viewSemaphore = new Semaphore(1);
    private static Semaphore addSemaphore = new Semaphore(1);
    private static Semaphore updateSemaphore = new Semaphore(1);

    private static final ConcurrentHashMap<String, ConcurrentLinkedQueue<Logger>> loggerRepoMap = new ConcurrentHashMap<>();

    public static void view(Logger logger){
        if(viewSemaphore.tryAcquire()){
            loggerRepoMap.entrySet().stream().forEach(entry -> {
                logger.info("registered logger class: {}", entry.getKey());
            });
        }
    }

    public static boolean add(String clazz, Logger logger){
        if(addSemaphore.tryAcquire()) {
            ConcurrentLinkedQueue<Logger> queue = loggerRepoMap.get(clazz);
            if (queue == null) {
                queue = new ConcurrentLinkedQueue<>();
                loggerRepoMap.put(clazz, queue);
            }
            queue.add(logger);
            addSemaphore.release(1);
            return true;
        }
        return false;
    }

    public static boolean hasClassName(String clzzName) {
        if(StringUtils.isNotBlank(clzzName)) {
            return loggerRepoMap.containsKey(clzzName);
        }
        return false;
    }

    public static boolean changeLoggerLevel(Logger iLogger, String clzzName, Level level) {
        if(updateSemaphore.tryAcquire()) {
            iLogger.info("changing logger level to {} for {}", level.toString(), clzzName);
            ConcurrentLinkedQueue<Logger> queue = loggerRepoMap.get(clzzName);
            if (queue == null || queue.size() == 0) {
                return true;
            }
            final ch.qos.logback.classic.Level lvl = ch.qos.logback.classic.Level.toLevel(level.name());
            queue.stream().forEach(logger -> {
                if ((logger != null) && (logger instanceof ch.qos.logback.classic.Logger)) {
                    ch.qos.logback.classic.Logger log = (ch.qos.logback.classic.Logger) logger;
                    if((log.getLevel() == null) || (log.getLevel() != null && log.getLevel().levelInt != lvl.levelInt)) {
                        log.setLevel(lvl);
                        iLogger.info("updated logger level to {} for {}", lvl.levelStr, log.getName());
                    }
                }
            });
            updateSemaphore.release(1);
            return true;
        }
        return false;
    }
}
