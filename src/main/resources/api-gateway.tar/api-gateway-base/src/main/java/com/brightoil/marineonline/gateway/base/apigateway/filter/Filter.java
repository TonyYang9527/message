package com.brightoil.marineonline.gateway.base.apigateway.filter;

public interface Filter<T extends Delegate> {

    void doFilter(FilterConfig<T> cfg);

}
