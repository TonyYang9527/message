package com.brightoil.marineonline.gateway.base.apigateway.service;

public interface ConfigService {
    Object get(String key);
}
