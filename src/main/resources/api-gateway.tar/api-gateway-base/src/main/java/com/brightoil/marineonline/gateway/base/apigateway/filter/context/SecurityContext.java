package com.brightoil.marineonline.gateway.base.apigateway.filter.context;

import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;

public abstract class SecurityContext extends CommonContext implements Security {

    private boolean authRequired = true;
    private boolean guestToken  = false;
    private String userId;
    private String anonToken;
    private String authToken;

    @Override
    public FilterConfig reset() {
        this.authRequired = false;
        return super.reset();
    }

    @Override
    public boolean isAuthRequired() {
        return authRequired;
    }

    @Override
    public FilterConfig setAuthRequired(boolean authRequired) {
        this.authRequired = authRequired;
        return filterConfig;
    }

    public FilterConfig setAuthToken(String authToken) {
        this.authToken = authToken;
        return filterConfig;
    }

    @Override
    public String getAnonToken() {
        return anonToken;
    }

    @Override
    public FilterConfig setAnonToken(String token) {
        this.anonToken = token;
        return filterConfig;
    }

    @Override
    public FilterConfig setGuestToken(boolean auth) {
        guestToken = auth;
        return filterConfig;
    }

    @Override
    public boolean isGuestToken() {
        return guestToken;
    }

    @Override
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String getAuthToken() {
        return authToken;
    }

}
