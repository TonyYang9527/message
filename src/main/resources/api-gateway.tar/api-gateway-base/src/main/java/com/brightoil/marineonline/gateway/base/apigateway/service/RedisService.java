package com.brightoil.marineonline.gateway.base.apigateway.service;

import io.lettuce.core.pubsub.RedisPubSubAdapter;
import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

import java.util.Set;

public interface RedisService {

    public void registerListener(String channelName, RedisPubSubAdapter<String, String> listener, Handler<AsyncResult<Void>> handler);

    public void unRegisterListener(String channelName, RedisPubSubAdapter<String, String> listener, Handler<AsyncResult<Void>> handler);

    public void publishMessage(String channelName, String event, Handler<AsyncResult<Boolean>> handler);

    public void getValueByKey(String key, Handler<AsyncResult<String>> handler);

    public void registerKey(String key, String value, int timeToLive, Handler<AsyncResult<Boolean>> handler);

    public void unregisterKey(String key, Handler<AsyncResult<Void>> handler);

    public void addMemberByKey(String key, String member, Handler<AsyncResult<Long>> handler);

    public void getMembersByKey(String key, Handler<AsyncResult<Set<String>>> handler);

    public void removeMemberByKey(String key, String member, Handler<AsyncResult<Long>> handler);

}
