package com.brightoil.marineonline.gateway.base.apigateway.handler;

import com.brightoil.marineonline.gateway.base.apigateway.service.HttpHeaderService;
import com.brightoil.marineonline.gateway.base.apigateway.service.UUIDServiceImpl;
import com.brightoil.marineonline.gateway.base.apigateway.service.HttpHeaderService;
import com.brightoil.marineonline.gateway.base.apigateway.service.UUIDServiceImpl;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.vertx.core.Handler;
import io.vertx.core.http.HttpHeaders;
import io.vertx.reactivex.core.http.HttpServerResponse;
import io.vertx.reactivex.ext.web.RoutingContext;

/**
 * todo: all request must have an valid header to confirmed as valid internal micro-services
 */
@Singleton
public class WelcomeHandler implements Handler<RoutingContext> {

    @Inject
    private UUIDServiceImpl uuidService;

    @Inject
    HttpHeaderService headerService;

    @Override
    public void handle(RoutingContext ctx) {
        headerService.allowResponseHeader(uuidService.getUniqueRequestId(), ctx.response().headers());

        HttpServerResponse res = ctx.response();
        res.setChunked(true);

        res.headers().set(HttpHeaders.CONTENT_TYPE.toString(), "text/html; charset=utf-8");

        res.write("<br/>Welcome to API Gateway!!!");

        res.end();
    }
}