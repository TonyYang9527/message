package com.brightoil.marineonline.gateway.base.apigateway.service;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

public interface AuthService {

    public void authenticate(String reqId, String serviceName, String uri, String token, Handler<AsyncResult<Integer>> completer);

}