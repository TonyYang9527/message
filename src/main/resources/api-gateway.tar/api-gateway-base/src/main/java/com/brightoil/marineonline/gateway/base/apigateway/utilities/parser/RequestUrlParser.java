package com.brightoil.marineonline.gateway.base.apigateway.utilities.parser;
/*
 * Copyright (C) 2016 venshine.cn@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;

import java.util.HashMap;

/**
 *
 * @author venshine
 */
public class RequestUrlParser {

    /**
     */
    private String mUrl;

    /**
     */
    private String mProtocol;

    /**
     */
    private String mHost;

    /**
     */
    private int mPort = Constants.DEF_APP_PORT;

    /**
     */
    private String mPath;

    /**
     */
    private HashMap<String, String> mParamMap;


    public RequestUrlParser(String url) {
        if (url == null || url.length() == 0) {
            throw new IllegalArgumentException("url is illegal!");
        }
        mUrl = url;
        startParse();
    }

    /**
     */
    private void startParse() {
        String[] parts = mUrl.split("[?]");
        if (parts != null && parts.length > 0) {
            String[] entity = parts[0].split("://");
            if (entity != null && entity.length > 1) {
                mProtocol = entity[0];
                String f = entity[1];
                if (f.contains(":")) {
                    mHost = f.substring(0, f.indexOf(":"));
                    if (f.contains("/")) {
                        mPort = Integer.parseInt(f.substring(f.indexOf(":") + 1, f.indexOf("/")));
                        mPath = f.substring(f.indexOf("/"));
                    } else {
                        mPort = Integer.parseInt(f.substring(f.indexOf(":") + 1));
                        mPath = "";
                    }
                } else {
                    if (f.contains("/")) {
                        mHost = f.substring(0, f.indexOf("/"));
                        mPath = f.substring(f.indexOf("/"));
                    } else {
                        mHost = f;
                        mPath = "";
                    }
                }
            }
            if (parts.length > 1) {
                String[] params = parts[1].split("[&]");
                if (params != null && params.length > 0) {
                    mParamMap = new HashMap<String, String>(params.length);
                    for (String param : params) {
                        if (!param.contains("=")) {
                            continue;
                        }
                        String[] s = param.split("[=]");
                        if (s != null) {
                            if (s.length == 2) {
                                String v = s[1];
                                if (v.contains("#")) {
                                    v = v.substring(0, v.indexOf("#"));
                                }
                                mParamMap.put(s[0], v);
                            } else {
                                if (s.length == 1) {
                                    mParamMap.put(s[0], null);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     *
     * @return
     */
    public String getProtocol() {
        return mProtocol;
    }

    /**
     *
     * @return
     */
    public String getHost() {
        return mHost;
    }

    /**
     *
     * @return
     */
    public int getPort() {
        return mPort;
    }

    /**
     *
     * @return
     */
    public String getPath() {
        return mPath;
    }

    /**
     *
     * @return
     */
    public HashMap<String, String> getParams() {
        return mParamMap;
    }


}