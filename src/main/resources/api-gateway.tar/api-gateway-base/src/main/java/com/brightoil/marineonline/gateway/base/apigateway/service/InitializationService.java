package com.brightoil.marineonline.gateway.base.apigateway.service;

public interface InitializationService {

    public void init();
}
