package com.brightoil.marineonline.gateway.base.guicetools.scan;

import com.brightoil.marineonline.gateway.base.guicetools.util.ConfigurationScanUtil;
import com.brightoil.marineonline.gateway.base.guicetools.util.ConfigurationScanUtil;
import com.google.inject.AbstractModule;

public class ConfigurationScanModule extends AbstractModule {

    @Override
    public void configure() {
        try {
            ConfigurationScanUtil.list.getOrThrow().forEach(this::install);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to install module", e);
        }
    }
}