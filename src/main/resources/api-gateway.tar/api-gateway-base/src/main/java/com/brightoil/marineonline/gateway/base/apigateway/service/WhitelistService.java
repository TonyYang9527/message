package com.brightoil.marineonline.gateway.base.apigateway.service;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

public interface WhitelistService {

    public void refreshWhitelist(boolean success);

    public void retrieveWhitelist(Handler<AsyncResult<Boolean>> completer);

    public void isResourceInWhitelist(String serviceName, int port, String uri, Handler<AsyncResult<Boolean>> iHandler);

}
