package com.brightoil.marineonline.gateway.base.guicetools.util;

import com.brightoil.marineonline.gateway.base.guicetools.scan.Order;
import com.google.common.collect.Sets;
import com.google.inject.AbstractModule;
import org.reflections.Reflections;

import java.lang.annotation.Annotation;
import java.util.LinkedHashSet;
import java.util.Set;

public class ComponentScanUtil extends AbstractModule {

    public static LinkedHashSet<Class<?>> list = new LinkedHashSet<>();

    public static LinkedHashSet<Class<?>> configure(String packageName, final Class<? extends Annotation>... installAnnotationArray) {
        Set<Class<? extends Annotation>> installAnnotations = Sets.newHashSet(installAnnotationArray);
        Reflections packageReflections = new Reflections(packageName);
        installAnnotations.stream().map(packageReflections::getTypesAnnotatedWith).flatMap(Set::stream).filter(ComponentScanUtil::isClass).sorted(ComponentScanUtil::orderClass).distinct().forEach(clzz -> {
            list.add(clzz);
        });
        return list;
    }

    private static boolean isClass(Class<?> clazz) {
        boolean filter = (!clazz.isInterface());
        return filter;
    }

    private static int orderClass(Class<?> a, Class<?> b) {
        int va = a.isAnnotationPresent(Order.class) ? a.getAnnotation(Order.class).value() : Integer.MAX_VALUE;
        int vb = b.isAnnotationPresent(Order.class) ? b.getAnnotation(Order.class).value() : Integer.MAX_VALUE;
        return Integer.compare(va, vb);
    }

}