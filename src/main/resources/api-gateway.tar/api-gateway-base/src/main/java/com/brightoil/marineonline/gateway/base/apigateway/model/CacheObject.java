package com.brightoil.marineonline.gateway.base.apigateway.model;

public class CacheObject<T> {

    T obj;

    long cachedTime;

    public void set(T obj, long cachedTime){
        this.obj = obj;
        this.cachedTime = cachedTime;
    }

    public long getCachedTime() {
        return cachedTime;
    }

    public T getObj() {
        return obj;
    }
}
