package com.brightoil.marineonline.gateway.base.apigateway.server;

import com.brightoil.marineonline.gateway.base.apigateway.server.listener.CommonListenerService;
import com.brightoil.marineonline.gateway.base.apigateway.server.listener.SelfListenerService;
import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigService;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import org.slf4j.Logger;

@Singleton
public class ListenerServiceImpl implements ListenerService {

    @InjectLogger
    Logger logger;

    @Inject
    ConfigService configService;

    @Inject
    SelfListenerService selfListenerService;

    @Inject
    CommonListenerService commonListenerService;

    @Override
    public void registerListener(Handler<AsyncResult<Void>> completer) {
        boolean requiredComListener = "Y".equalsIgnoreCase((String) configService.get(Config.ENV_COMMON_LISTENER));
        boolean requiredSlfListener = "Y".equalsIgnoreCase((String) configService.get(Config.ENV_SELF_LISTENER));
        if(requiredComListener && requiredSlfListener){
            Future<Void> future = Future.future();
            future.setHandler(e -> {
                logger.info("register individual listener");
                selfListenerService.registerListener(completer);
            });
            logger.info("register common listener");
            commonListenerService.registerListener(future.completer());
            return;
        }
        if(requiredComListener){
            logger.info("register common listener");
            commonListenerService.registerListener(completer);
            return;
        }
        if(requiredSlfListener){
            logger.info("register common listener");
            selfListenerService.registerListener(completer);
            return;
        }
        completer.handle(Future.succeededFuture());
    }
}
