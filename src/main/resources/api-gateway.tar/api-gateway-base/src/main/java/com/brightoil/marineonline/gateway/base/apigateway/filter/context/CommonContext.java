package com.brightoil.marineonline.gateway.base.apigateway.filter.context;

import com.brightoil.marineonline.gateway.base.apigateway.filter.DelegateContext;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;

public abstract class CommonContext extends DelegateContext implements Common {

    private String serviceName;
    private String serviceURI;
    private int    servicePort;

    @Override
    public FilterConfig reset() {
        this.serviceName = null;
        this.serviceURI  = null;
        this.servicePort = -1;
        return super.reset();
    }

    @Override
    public String getServiceName() {
        return serviceName;
    }

    public FilterConfig setServiceName(String serviceName) {
        this.serviceName = serviceName;
        return filterConfig;
    }

    @Override
    public String getServiceURI() {
        return serviceURI;
    }

    public FilterConfig setServiceURI(String serviceURI) {
        this.serviceURI = serviceURI;
        return filterConfig;
    }

    @Override
    public int getServicePort() {
        return servicePort;
    }

    public FilterConfig setServicePort(int servicePort) {
        this.servicePort = servicePort;
        return filterConfig;
    }
}
