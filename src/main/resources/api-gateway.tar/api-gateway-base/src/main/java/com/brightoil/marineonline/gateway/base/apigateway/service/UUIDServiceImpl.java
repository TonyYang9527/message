/*
 * Copyright (c) 2018. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Singleton;
import io.vertx.core.Handler;
import io.vertx.reactivex.core.Vertx;
import org.slf4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

@Singleton
public class UUIDServiceImpl implements UUIDService {

    @InjectLogger
    Logger logger;

    private Random random = new Random(10000000);

    private static final long DEF_REFRESH_TIMER = 43200000;

    private static AtomicInteger id = new AtomicInteger();

    public boolean init(){
        autoRefresh(VertxHolder.get());
        return true;
    }

    private void autoRefresh(Vertx vertx) {
        vertx.setTimer(calcNextRefreshDuration(), new Handler<Long>() {
            @Override
            public void handle(Long event) {
                id.set(0);
                autoRefresh(vertx);
            }
        });
    }

    private long calcNextRefreshDuration(){
        try {
            SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat dttm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date now = new Date(System.currentTimeMillis());
            String lastMinuteToday = String.format("%s 23:59:59", dt.format(now));
            Date today = dttm.parse(lastMinuteToday);
            Date tmr = new Date(today.getTime() + 1000l);
            return (tmr.getTime() - now.getTime());
        } catch (Throwable e) {
            logger.error("calculate next refresh duration for UUID generator failed using default value {} now", DEF_REFRESH_TIMER, e);
            return DEF_REFRESH_TIMER;
        }
    }

    private long getUniqueID() {
        return id.getAndIncrement();
    }

    public String getUniqueRequestId() {
        return String.format("%d-%06d", System.currentTimeMillis(), getUniqueID());
    }

    public String getUniqueRequestId(String key) {
        return String.format("%d-%06d-%s", System.currentTimeMillis(), getUniqueID(), key);
    }

    public int getUniqueIntId(){
        return random.nextInt();
    }
}
