package com.brightoil.marineonline.gateway.base.apigateway.utilities.holder;

import io.vertx.reactivex.core.Vertx;

public class VertxHolder {

    private static Vertx vertx;

    public static void set(Vertx vertx){
        VertxHolder.vertx = vertx;
    }

    public static Vertx get(){
        return vertx;
    }

}
