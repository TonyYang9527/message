package com.brightoil.marineonline.gateway.base.apigateway.server.listener;

import com.brightoil.marineonline.gateway.base.apigateway.model.EventType;
import com.brightoil.marineonline.gateway.base.apigateway.service.ChannelEventService;
import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigService;
import com.brightoil.marineonline.gateway.base.apigateway.service.RedisService;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import org.slf4j.Logger;

@Singleton
public class CommonListenerServiceImpl extends AbstractListenerService implements CommonListenerService {

    @InjectLogger
    Logger logger;

    @Inject
    ConfigService configService;

    @Inject
    RedisService redisService;

    @Inject
    ChannelEventService channelEventService;

    String channelName;

    EventType heartbeatEventType;

    public boolean init(){
        try{
            super.init();
            channelName = (String) configService.get(Config.ENV_CHANNEL);
            heartbeatEventType = EventType.COM_HEARTBEAT;
        }catch (Throwable ex){
            logger.error("init failure due to {}", ex.getMessage(), ex);
            return false;
        }
        return true;
    }

    @Override
    protected Logger getLogger() {
        return logger;
    }

    @Override
    protected RedisService getRedisService() {
        return redisService;
    }

    @Override
    protected ChannelEventService getChannelEventService() {
        return channelEventService;
    }

    @Override
    protected String getChannelName() {
        return channelName;
    }

    @Override
    protected EventType getHeartbeatEventType() {
        return heartbeatEventType;
    }
}
