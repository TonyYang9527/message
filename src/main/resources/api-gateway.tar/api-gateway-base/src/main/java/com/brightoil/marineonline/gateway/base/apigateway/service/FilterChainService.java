package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterChain;
import com.brightoil.marineonline.gateway.base.apigateway.model.FilterType;

public interface FilterChainService {

    void config();

    FilterChain getFilterChain(FilterType type);

}
