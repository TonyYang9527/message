package com.brightoil.marineonline.gateway.base.apigateway.service;

import io.vertx.reactivex.core.http.HttpServerRequest;
import io.vertx.reactivex.core.http.HttpServerResponse;

public interface HttpResponseService {

    void response(String reqId, HttpServerRequest req, HttpServerResponse res, int code);

    void response(String reqId, HttpServerRequest req, HttpServerResponse res, int code, Throwable e);
}
