package com.brightoil.marineonline.gateway.base.apigateway.repo;

import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.pubsub.StatefulRedisPubSubConnection;
import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

import java.util.concurrent.ConcurrentLinkedQueue;

public interface RedisRepo{
    public void getSubConnection(String channel, Handler<AsyncResult<StatefulRedisPubSubConnection>> completer);
    public void getPubConnection(Handler<AsyncResult<StatefulRedisPubSubConnection>> completer);
    public void getConnection(Handler<AsyncResult<StatefulRedisConnection>> completer);
    public void releaseConnection(StatefulRedisConnection connection);
    public void releasePubConnection(StatefulRedisPubSubConnection connection);
    public void releaseSubConnection(String channel, StatefulRedisPubSubConnection connection);
    public void closeSubConnections(String channel, Handler<AsyncResult<Void>> completer);
    public void obtainSubConnections(String channel, Handler<AsyncResult<ConcurrentLinkedQueue<StatefulRedisPubSubConnection>>> completer);

}
