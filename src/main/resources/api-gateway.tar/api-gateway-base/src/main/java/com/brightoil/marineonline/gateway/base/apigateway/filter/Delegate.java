package com.brightoil.marineonline.gateway.base.apigateway.filter;

public interface Delegate {

    String          getRequestId();
    FilterConfig    setRequestId(String requestId);
    FilterConfig    init(FilterConfig filterConfig);
    FilterConfig    reset();
    FilterConfig    filterConfig();
}
