package com.brightoil.marineonline.gateway.base.apigateway.utilities.holder;

public class HostAddrHolder {

    private static String hostAddr;

    private static String hostName;

    private static String host;

    public static void setName(String hostName){
        HostAddrHolder.hostName = hostName;
    }

    public static String getName(){
        return hostName;
    }

    public static void setAddr(String hostAddr){
        HostAddrHolder.hostAddr = hostAddr;
    }

    public static String getAddr(){
        return hostAddr;
    }

    public static String getHost() {
        return host;
    }

    public static void setHost(String h) {
        host = h;
    }
}
