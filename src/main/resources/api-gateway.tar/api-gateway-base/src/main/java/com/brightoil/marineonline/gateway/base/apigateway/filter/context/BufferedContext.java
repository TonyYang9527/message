package com.brightoil.marineonline.gateway.base.apigateway.filter.context;

import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;

public abstract class BufferedContext extends SecurityContext implements Buffered {

    private String dataId;
    private String data;

    @Override
    public FilterConfig reset() {
        this.data = null;
        return super.reset();
    }

    public String getData() {
        return data;
    }

    public FilterConfig setData(String data) {
        this.data = data;
        return filterConfig;
    }

    @Override
    public String getDataId() {
        return dataId;
    }

    @Override
    public FilterConfig setDataId(String dataId) {
        this.dataId = dataId;
        return filterConfig;
    }
}
