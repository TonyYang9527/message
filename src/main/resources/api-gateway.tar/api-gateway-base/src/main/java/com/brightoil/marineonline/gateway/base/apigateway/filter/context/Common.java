package com.brightoil.marineonline.gateway.base.apigateway.filter.context;

import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;
import com.brightoil.marineonline.gateway.base.apigateway.filter.Delegate;

public interface Common extends Delegate {

    String      getServiceName();
    String      getServiceURI();
    int         getServicePort();

    FilterConfig setServiceName(String name);
    FilterConfig setServiceURI(String uri);
    FilterConfig setServicePort(int port);
}
