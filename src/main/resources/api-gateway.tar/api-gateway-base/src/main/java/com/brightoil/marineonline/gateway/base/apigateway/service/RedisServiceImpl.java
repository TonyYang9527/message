package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.repo.RedisRepo;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.lettuce.core.RedisFuture;
import io.lettuce.core.SetArgs;
import io.lettuce.core.api.async.RedisAsyncCommands;
import io.lettuce.core.pubsub.RedisPubSubAdapter;
import io.lettuce.core.pubsub.api.async.RedisPubSubAsyncCommands;
import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import org.slf4j.Logger;

import java.util.Set;

@Singleton
public class RedisServiceImpl implements RedisService {

    @InjectLogger
    private Logger logger;

    @Inject
    private RedisRepo redisRepo;


    @Override
    public void registerListener(String channelName, RedisPubSubAdapter<String, String> listener, Handler<AsyncResult<Void>> handler) {
        redisRepo.getSubConnection(channelName, success -> {
            try {
                success.result().addListener(listener);
                RedisPubSubAsyncCommands<String, String> command = success.result().async();
                RedisFuture<Void> future = command.subscribe(channelName);
                future.handleAsync((Void v, Throwable t) -> {
                    redisRepo.releaseSubConnection(channelName, success.result());
                    if(t != null){
                        handler.handle(Future.failedFuture(t));
                        return null;
                    }
                    handler.handle(Future.succeededFuture());
                    return null;
                });
            }catch (Exception e){
                redisRepo.releaseSubConnection(channelName, success.result());
                handler.handle(Future.failedFuture(e));
            }
        });
    }

    @Override
    public void unRegisterListener(String channelName, RedisPubSubAdapter<String, String> listener, Handler<AsyncResult<Void>> handler) {
        redisRepo.obtainSubConnections(channelName, event -> {
            if(event.result() != null){
                event.result().iterator().forEachRemaining(connection -> {
                    try{
                        connection.removeListener(listener);
                    }catch (Throwable ex){};
                });
            }
            redisRepo.closeSubConnections(channelName, handler);
        });
    }

    @Override
    public void registerKey(String key, String value, int timeToLive, Handler<AsyncResult<Boolean>> handler) {
        redisRepo.getConnection(event -> {
            try {
                RedisAsyncCommands<String, String> command = event.result().async();
                SetArgs args = new SetArgs();
                args.ex(timeToLive);
                RedisFuture<String> future = command.set(key, value, args);
                future.handleAsync((String r, Throwable t) -> {
                    redisRepo.releaseConnection(event.result());
                    if(t != null){
                        handler.handle(Future.failedFuture(t));
                        return null;
                    }
                    if(r == null || r.trim().length() == 0 || (!"OK".equalsIgnoreCase(r))){
                        handler.handle(Future.succeededFuture(Boolean.FALSE));
                        return null;
                    }
                    handler.handle(Future.succeededFuture(Boolean.TRUE));
                    return null;
                });
            }catch (Exception e){
                redisRepo.releaseConnection(event.result());
                handler.handle(Future.failedFuture(e));
            }
        });
    }

    @Override
    public void unregisterKey(String key, Handler<AsyncResult<Void>> handler) {
        redisRepo.getConnection(event -> {
            try {
                RedisAsyncCommands<String, String> command = event.result().async();
                RedisFuture<Long> future = command.del(key);
                future.handleAsync((Long r, Throwable t) -> {
                    redisRepo.releaseConnection(event.result());
                    handler.handle(Future.succeededFuture());
                    return null;
                });
            }catch (Exception e){
                redisRepo.releaseConnection(event.result());
                handler.handle(Future.failedFuture(e));
            }
        });
    }

    @Override
    public void getValueByKey(String key, Handler<AsyncResult<String>> handler) {
        redisRepo.getConnection(success -> {
            try {
                RedisAsyncCommands<String, String> command = success.result().async();
                RedisFuture<String> future = command.get(key);
                future.handleAsync((s, throwable) -> {
                    redisRepo.releaseConnection(success.result());
                    if(throwable != null){
                        handler.handle(Future.failedFuture(throwable));
                        return null;
                    }
                    handler.handle(Future.succeededFuture(s));
                    return null;
                });
            }catch (Exception e){
                redisRepo.releaseConnection(success.result());
                handler.handle(Future.failedFuture(e));
            }
        });
    }

    @Override
    public void getMembersByKey(String key, Handler<AsyncResult<Set<String>>> handler) {
        redisRepo.getConnection(success -> {
            try {
                RedisAsyncCommands<String, String> command = success.result().async();
                RedisFuture<Set<String>> future = command.smembers(key);
                future.handleAsync((s, throwable) -> {
                    redisRepo.releaseConnection(success.result());
                    if(throwable != null){
                        handler.handle(Future.failedFuture(throwable));
                        return null;
                    }
                    handler.handle(Future.succeededFuture(s));
                    return null;
                });
            }catch (Exception e){
                redisRepo.releaseConnection(success.result());
                handler.handle(Future.failedFuture(e));
            }
        });
    }

    @Override
    public void removeMemberByKey(String key, String member, Handler<AsyncResult<Long>> handler) {
        redisRepo.getConnection(success -> {
            try {
                RedisAsyncCommands<String, String> command = success.result().async();
                RedisFuture<Long> future = command.srem(key, member);
                future.handleAsync((s, throwable) -> {
                    redisRepo.releaseConnection(success.result());
                    if(throwable != null){
                        handler.handle(Future.failedFuture(throwable));
                        return null;
                    }
                    handler.handle(Future.succeededFuture(s));
                    return null;
                });
            }catch (Exception e){
                redisRepo.releaseConnection(success.result());
                handler.handle(Future.failedFuture(e));
            }
        });
    }

    @Override
    public void addMemberByKey(String key, String member, Handler<AsyncResult<Long>> handler) {
        redisRepo.getConnection(success -> {
            try {
                RedisAsyncCommands<String, String> command = success.result().async();
                RedisFuture<Long> future = command.sadd(key, member);
                future.handleAsync((s, throwable) -> {
                    redisRepo.releaseConnection(success.result());
                    if(throwable != null){
                        handler.handle(Future.failedFuture(throwable));
                        return null;
                    }
                    handler.handle(Future.succeededFuture(s));
                    return null;
                });
            }catch (Exception e){
                redisRepo.releaseConnection(success.result());
                handler.handle(Future.failedFuture(e));
            }
        });
    }

    @Override
    public void publishMessage(String channelName, String event, Handler<AsyncResult<Boolean>> handler) {
        redisRepo.getPubConnection(success -> {
            try {
                RedisAsyncCommands<String, String> command = success.result().async();
                RedisFuture<Long> future = command.publish(channelName, event);
                future.handleAsync((Long r, Throwable t) -> {
                    redisRepo.releasePubConnection(success.result());
                    if(t != null){
                        handler.handle(Future.failedFuture(t));
                        return null;
                    }
                    handler.handle(Future.succeededFuture(Boolean.TRUE));
                    return null;
                });
            }catch (Exception e){
                redisRepo.releasePubConnection(success.result());
                handler.handle(Future.failedFuture(e));
            }
        });
    }
}
