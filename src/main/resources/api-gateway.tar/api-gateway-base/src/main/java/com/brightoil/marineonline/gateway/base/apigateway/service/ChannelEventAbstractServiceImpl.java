package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;
import com.brightoil.marineonline.gateway.base.apigateway.model.EventType;
import com.brightoil.marineonline.gateway.base.guicetools.logger.LogRepository;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.event.Level;

public abstract class ChannelEventAbstractServiceImpl implements ChannelEventService {
    
    public void handleChannelEvent(EventType eventType, JsonObject channelEvent) {
        getLogger().info("received new channel event {}:{}", eventType.name(), channelEvent);
        switch (eventType){
            case BLACKLIST:
                try {
                    handleBlacklistEvent(channelEvent);
                }catch (Throwable ex){
                    getLogger().error("handle event {} failure due to {}", eventType.name(), ex.getMessage());
                }
                break;
            case LOGGING:
                try {
                    handleLoggingEvent(channelEvent);
                }catch (Throwable ex){
                    getLogger().error("handle event {} failure due to {}", eventType.name(), ex.getMessage());
                }
                break;
            default:
                handleEvent(eventType, channelEvent);
                break;
        }
    }

    private void handleBlacklistEvent(JsonObject data) {
        if(data == null) {
            return;
        }
        if(!data.containsKey(Constants.EVENT_PARAM_BLACKLIST_HOST_ADDR)){
            getLogger().error("no property {} available in event data {}", Constants.EVENT_PARAM_BLACKLIST_HOST_ADDR, data);
            return;
        }
        if(!data.containsKey(Constants.EVENT_PARAM_BLACKLIST_ACTION)){
            getLogger().error("no property {} available in event data {}", Constants.EVENT_PARAM_BLACKLIST_ACTION, data);
            return;
        }
        JsonArray hostAddrLst = data.getJsonArray(Constants.EVENT_PARAM_BLACKLIST_HOST_ADDR);
        String action   = data.getString(Constants.EVENT_PARAM_BLACKLIST_ACTION);
        if(hostAddrLst == null || hostAddrLst.size() == 0){
            getLogger().error("empty property {} available in event data {}", Constants.EVENT_PARAM_BLACKLIST_HOST_ADDR, data);
            return;
        }
        if(StringUtils.isBlank(action)){
            getLogger().error("empty property {} available in event data {}", Constants.EVENT_PARAM_BLACKLIST_ACTION, data);
            return;
        }
        try{
            boolean add = Constants.EVENT_PARAM_BLACKLIST_ACTION_ADD.equalsIgnoreCase(action);
            boolean rm  = Constants.EVENT_PARAM_BLACKLIST_ACTION_RM.equalsIgnoreCase(action);
            hostAddrLst.stream().forEach(o -> {
                if((o != null) && (o instanceof String)){
                    String addr = (String)o;
                    if(add){
                        getBlacklistService().addHost(addr);
                    }
                    if(rm){
                        getBlacklistService().removedHost(addr);
                    }
                }
            });
        }catch (Throwable ex){
            getLogger().error("invalid blacklist data found in event data {}", data, ex);
        }
    }

    private void handleLoggingEvent(JsonObject data) {
        if(data == null) {
            return;
        }
        if(!data.containsKey(Constants.EVENT_PARAM_LOGGING_CLASS_NAME)){
            getLogger().error("no property {} available in event data {}", Constants.EVENT_PARAM_LOGGING_CLASS_NAME, data);
            return;
        }
        if(!data.containsKey(Constants.EVENT_PARAM_LOGGING_LEVEL)){
            getLogger().error("no property {} available in event data {}", Constants.EVENT_PARAM_LOGGING_LEVEL, data);
            return;
        }
        JsonArray clzzNames  = data.getJsonArray(Constants.EVENT_PARAM_LOGGING_CLASS_NAME);
        String loggerLvl     = data.getString(Constants.EVENT_PARAM_LOGGING_LEVEL);
        if(clzzNames == null || clzzNames.size() == 0){
            getLogger().error("empty property {} available in event data {}", Constants.EVENT_PARAM_LOGGING_CLASS_NAME, data);
            return;
        }
        if(StringUtils.isBlank(loggerLvl)){
            getLogger().error("empty property {} available in event data {}", Constants.EVENT_PARAM_LOGGING_LEVEL, data);
            return;
        }
        Level level = null;
        try{
            getLogger().debug("logger name [{}]", loggerLvl);
            level = Level.valueOf(loggerLvl.trim().toUpperCase());
        }catch (Throwable ex){
            getLogger().error("invalid logger level found in event data {}", data, ex);
            return;
        }
        try{
            final Level lvl = level;
            clzzNames.stream().forEach(o -> {
                if((o != null) && (o instanceof String)){
                    String className = (String)o;
                    className = className.trim();
                    if(LogRepository.hasClassName(className)) {
                        updateLoggerLevel(className, lvl);
                    }
                }
            });
        }catch (Throwable ex){
            getLogger().error("invalid logger parameters found in event data {}", data, ex);
        }
    }

    private void updateLoggerLevel(String clzzName, Level level) {
        boolean success = false;
        do{
            success = LogRepository.changeLoggerLevel(getLogger(), clzzName, level);
        }while (!success);
    }

    protected abstract Logger getLogger();

    protected abstract BlacklistService getBlacklistService();

    protected abstract void handleEvent(EventType eventType, JsonObject channelEvent);
}
