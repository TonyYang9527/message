package com.brightoil.marineonline.gateway.base.apigateway.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FilterChain implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(FilterChain.class);

    private String name;

    private Filter[] filters;

    public FilterChain(String name, Filter[] filters) {
        this.name = name;
        this.filters = filters;
    }

    @Override
    public void doFilter(FilterConfig cfg) {
        try{
            int index = cfg.autoRotate();
            if(index >= filters.length){
                cfg.stopped().reset().release();
                return;
            }
            if(cfg.isStopping()){
                cfg.stopped().reset().release();
                return;
            }
            Filter filter = filters[index];
            if(filter == null) {
                cfg.stopped().reset().release();
                return;
            }
            cfg.started(filter);
            filter.doFilter(cfg);
        }catch (Throwable ex){
            logger.error("filter chain exception from {}", cfg.filter().getClass().getName(), ex);
            cfg.stopped().reset().release();
        }
    }
}
