package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Singleton;
import io.vertx.reactivex.core.Vertx;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

import java.util.concurrent.ConcurrentHashMap;

@Singleton
public class BlacklistServiceImpl implements BlacklistService {

    private static final int TIME = 300000;

    @InjectLogger
    Logger logger;

    private ConcurrentHashMap<String, Integer> blackList = new ConcurrentHashMap<>();

    private Vertx vertx;

    public boolean init(){
        vertx = VertxHolder.get();
        listening();
        return true;
    }

    private void listening() {
        try{
            vertx.setTimer(TIME, event -> {
                try{
                    blackList.entrySet().stream().forEach(stringIntegerEntry -> {
                        logger.info("blacklist : {}", stringIntegerEntry.getKey());
                    });
                    listening();
                }catch (Throwable ex){
                    listening();
                }
            });
        }catch (Throwable ex){
            listening();
        }
    }

    @Override
    public boolean hasHost(String host) {
        if(host != null) {
            return blackList.containsKey(host);
        }
        return false;
    }

    @Override
    public void addHost(String host) {
        if(StringUtils.isNotBlank(host) && (!hasHost(host))){
            blackList.put(host,0);
        }
    }

    @Override
    public void removedHost(String host) {
        if(StringUtils.isNotBlank(host) && hasHost(host)){
            blackList.remove(host);
        }
    }

    @Override
    public boolean check(String uuid, String host) {
        // todo: need to check the x-forward-for
        if(StringUtils.isNotBlank(host)) {
            if (blackList.containsKey(host)) {
                logger.debug("[{}]-[{}]-client been blocked", uuid, host);
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;

    }
}
