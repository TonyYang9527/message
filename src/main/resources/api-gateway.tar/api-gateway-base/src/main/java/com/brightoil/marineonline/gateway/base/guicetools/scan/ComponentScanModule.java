package com.brightoil.marineonline.gateway.base.guicetools.scan;

import com.brightoil.marineonline.gateway.base.guicetools.util.ComponentScanUtil;
import com.brightoil.marineonline.gateway.base.guicetools.util.ComponentScanUtil;
import com.google.common.collect.Sets;
import com.google.inject.AbstractModule;
import com.google.inject.TypeLiteral;
import com.google.inject.matcher.AbstractMatcher;
import com.google.inject.name.Names;
import com.google.inject.spi.InjectionListener;
import com.google.inject.spi.TypeEncounter;
import com.google.inject.spi.TypeListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Scan package and sub package, bind all classes with type annotation.
 * <p>
 * Default is @Component annotation
 */
public class ComponentScanModule extends AbstractModule {

    private static final Logger logger = LoggerFactory.getLogger(ComponentScanModule.class);

    private final String packageName;
    private final Set<Class<? extends Annotation>> bindingAnnotations;

    private List<String> failed = new ArrayList<>();

    /**
     * Scan package and sub package, bind all classes with @Component annotation.
     *
     * @param packageName package to scan
     */
    public ComponentScanModule(String packageName) {
        this(packageName, Component.class);
    }

    /**
     * Scan package and sub package, bind all classes with type annotation
     *
     * @param packageName        package to scan
     * @param bindingAnnotations type annotations to bind
     */
    @SafeVarargs
    public ComponentScanModule(String packageName, final Class<? extends Annotation>... bindingAnnotations) {
        super();
        this.packageName = packageName;
        this.bindingAnnotations = Sets.newHashSet(bindingAnnotations);
    }

    @Override
    public void configure() {
        initialization();
        scanning();
    }

    private void scanning() {
        ComponentScanUtil.list.forEach(this::bindClass);
    }

    private void bindClass(Class clazz) {
        try {
            Class<?> interfaceName = getInterfaceName(clazz);
            if (interfaceName != null) {
                if (interfaceName.getName().startsWith(packageName) && clazz.getSimpleName().startsWith(interfaceName.getSimpleName())) {
                    bind(interfaceName).to(clazz).asEagerSingleton();
                    logger.info("[loaded] {} - {}",interfaceName.getSimpleName(), clazz.getName());
                } else {
                    String name = getClazzName(clazz);
                    bind(interfaceName).annotatedWith(Names.named(name)).to(clazz).asEagerSingleton();
                    logger.info("[loaded] {} - {} [named - {}]",interfaceName.getSimpleName(), clazz.getName(), name);
                }
            } else {
                bind(clazz).asEagerSingleton();
                logger.info("[loaded] {}", clazz.getName());
            }
        }catch (Throwable ex){
            logger.info("[loading failure] {} {}", clazz.getName(), ex.getMessage(), ex);
        }
    }

    private String getClazzName(Class clazz) {
        String simpleName = clazz.getSimpleName();
        String annotationName = simpleName.substring(0, 1).toLowerCase().concat(simpleName.substring(1));
        if(annotationName.endsWith("Impl") || annotationName.endsWith("impl")){
            annotationName = annotationName.substring(0, annotationName.length() - 4);
        }
        return annotationName;
    }

    private Class<?> getInterfaceName(Class<?> clazz) {
        Class<?>[] classes = clazz.getInterfaces();
        if(classes == null || classes.length == 0){
            return null;
        }
        Class<?> interfaceClazz = null;
        int len = classes.length;
        String clazzName = clazz.getSimpleName();
        for(int i = 0 ; i < len ; i++){
            Class<?> clz = classes[i];
            String clzName = clz.getSimpleName();
            if(clazzName.startsWith(clzName) && clazzName.contains(clzName)){
                interfaceClazz = clz;
                break;
            }
        }
        if(interfaceClazz == null){
            interfaceClazz = classes[0];
        }
        return interfaceClazz;
    }

    private void initialization() {
        HasInitMethod initMethod = new HasInitMethod();
        InitInvoker initInvoker = new InitInvoker(failed);
        bindListener(initMethod, new TypeListener() {
            @Override
            public <I> void hear(TypeLiteral<I> type, TypeEncounter<I> encounter) {
                encounter.register(initInvoker);
            }
        });
    }

    public List<String> getFailed() {
        return failed;
    }

    class InitInvoker implements InjectionListener {

        private List<String> im;

        public InitInvoker(List<String> im) {
            this.im = im;
        }

        public void afterInjection(Object injectee) {
            Class<?> clazz = injectee.getClass();
            try {
                Object success = clazz.getMethod("init").invoke(injectee);
                if(success != null){
                    if(success instanceof Boolean && ((Boolean) success).booleanValue()){
                        logger.info("[initialize] {} succeed",clazz.getName());
                    }else {
                        im.add(clazz.getName());
                        logger.info("[initialize] {} failed",clazz.getName());
                    }
                }
            } catch (Exception e) {
                im.add(clazz.getName());
                logger.info("[initialize] {} failed due to {}",clazz.getName(), e.getLocalizedMessage(), e);
            }
        }
    }

    class HasInitMethod extends AbstractMatcher<TypeLiteral<?>> {
        public boolean matches(TypeLiteral<?> tpe) {
            boolean has = false;
            Method[] methods = tpe.getRawType().getMethods();
            if(methods != null){
                for(Method m : methods){
                    if(m.getName().equalsIgnoreCase("init")){
                        has = true;
                        break;
                    }
                }
            }
            return has;
        }
    }
}