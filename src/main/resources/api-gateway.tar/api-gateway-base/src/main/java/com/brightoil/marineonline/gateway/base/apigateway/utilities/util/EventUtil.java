package com.brightoil.marineonline.gateway.base.apigateway.utilities.util;

import com.brightoil.marineonline.gateway.base.apigateway.model.EventType;
import io.vertx.core.json.JsonObject;
import org.slf4j.LoggerFactory;

public class EventUtil {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(EventUtil.class);

    private EventType eventType;
    private JsonObject data = new JsonObject();

    public EventType getEventType() {
        return eventType;
    }

    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public String encode(){
        JsonObject obj = new JsonObject();
        try{
            obj.put("event-name", eventType.name());
            obj.put("data", data);
        }catch (Throwable ex){
            logger.error("decode json service properties failed due to {}", ex.getMessage(), ex);
        }
        return obj.toString();
    }

    public static EventUtil decode(String str){
        EventUtil obj = new EventUtil();
        try{
            JsonObject o = new JsonObject(str.trim());
            obj.setEventType(EventType.valueOf(o.getString("event-name")));
            obj.setData(o.getJsonObject("data"));
        }catch (Throwable ex){
            logger.error("decode json service properties failed due to {}", ex.getMessage(), ex);
        }
        return obj;
    }

    public JsonObject getData() {
        return data;
    }

    public void setData(JsonObject data) {
        this.data = data;
    }
}
