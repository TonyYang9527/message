package com.brightoil.marineonline.gateway.base.apigateway.filter.context;

import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;

public interface Buffered extends Security {

    String getData();
    String getDataId();

    FilterConfig setData(String data);
    FilterConfig setDataId(String id);

}
