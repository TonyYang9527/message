package com.brightoil.marineonline.gateway.base.apigateway.model;

public enum FilterType {

    HTTP(0),
    WEBSOCKET_AUTH(1),
    WEBSOCKET_PROXY(2),
    WEBSOCKET_QUIT(3),
    PUSH(4),
    DISTRIBUTION(5)
    ;

    private int code;

    FilterType(int code){
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
