package com.brightoil.marineonline.gateway.base.apigateway.filter.filters;

import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.apigateway.filter.Filter;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;
import com.brightoil.marineonline.gateway.base.apigateway.filter.context.Security;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigService;
import com.brightoil.marineonline.gateway.base.apigateway.service.WhitelistService;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigService;
import com.brightoil.marineonline.gateway.base.apigateway.service.WhitelistService;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.scan.Order;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.scan.Order;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import org.slf4j.Logger;

@Singleton
@Order(2)
public class WhitelistFilter implements Filter<Security> {

    @InjectLogger
    Logger logger;

    @Inject
    ConfigService configService;

    @Inject
    WhitelistService service;

    private String env;

    public boolean init(){
        try{
            env = (String) configService.get(Config.ENV);
        }catch (Throwable ex){
            logger.error("init failure due to {}", ex.getMessage(), ex);
            return false;
        }
        return true;
    }

    @Override
    public void doFilter(FilterConfig<Security> cfg) {
        try{
            Security ctx = cfg.get();
            String uri = ctx.getServiceURI();
            if(uri == null || uri.length() == 0){
                ctx.setAuthRequired(true).doFilter();
                return;
            }
            if(uri.contains("?")){
                int idx = uri.indexOf("?");
                if(idx != -1) {
                    uri = uri.substring(0, idx);
                }
            }
            service.isResourceInWhitelist(ctx.getServiceName(), ctx.getServicePort(), uri, e -> {
                if(e.cause() != null){
                    logger.error("[{}] - whitelist check error due to {}", ctx.getRequestId(), e.cause().getMessage(), e.cause());
                    cfg.doFilter();
                    return;
                }
                if(!e.succeeded()){
                    cfg.doFilter();
                    return;
                }
                // if resource in whitelist then authentication is not required, otherwise, authentication is required.
                ctx.setAuthRequired(!e.result().booleanValue()).doFilter();
            });
        }catch (Throwable ex){
            logger.error("[{}] - whitelist check failure due to {}", ex.getMessage(), ex);
            cfg.doFilter();
        }
    }
}
