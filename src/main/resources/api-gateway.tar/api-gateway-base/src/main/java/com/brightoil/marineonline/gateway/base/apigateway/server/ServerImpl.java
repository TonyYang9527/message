package com.brightoil.marineonline.gateway.base.apigateway.server;

import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigService;
import com.brightoil.marineonline.gateway.base.apigateway.service.WhitelistService;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.util.HttpTokenUtil;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.reactivex.core.Vertx;
import org.slf4j.Logger;

@Singleton
public class ServerImpl implements Server {

    @InjectLogger
    Logger logger;

    @Inject
    WhitelistService whitelistService;

    @Inject
    ConfigService configService;

    @Inject
    ListenerService listenerService;

    Vertx vertx;

    public boolean init(){
        vertx = VertxHolder.get();
        return true;
    }

    @Override
    public void start(Handler<AsyncResult<Void>> completer){registerListener(completer);}

    private void registerListener(Handler<AsyncResult<Void>> completer) {
        Future<Void> future = Future.future();
        future.setHandler(event -> {
            logger.debug("register listener callback");
            if (event.cause() != null) {
                logger.error("register redis listener failure, will be try again", event.cause());
                continueRegisterListener(completer);
                return;
            }
            if (!event.succeeded()) {
                logger.error("register redis listener failure, will be try again");
                continueRegisterListener(completer);
                return;
            }
            checkAndStart(completer);
        });
        logger.debug("register listener");
        listenerService.registerListener(future.completer());
    }

    private void continueRegisterListener(Handler<AsyncResult<Void>> completer) {
        vertx.setTimer(Constants.DEF_TIMER_TIME, event -> {
            registerListener(completer);
        });
    }

    private void checkAndStart(Handler<AsyncResult<Void>> completer) {
        whitelistService.retrieveWhitelist(e->{
            if(e.cause() != null){
                logger.error("retrieve whitelist failure due to {}, re-check again", e.cause().getMessage());
                repeatingCheckAndStart(completer);
                return;
            }
            if(!e.succeeded()){
                logger.error("retrieve whitelist unsuccessful, re-check again");
                repeatingCheckAndStart(completer);
                return;
            }
            if(!e.result().booleanValue()){
                logger.error("retrieve whitelist unsuccessful, re-check again");
                repeatingCheckAndStart(completer);
                return;
            }
            checkAndStartReady(completer);
        });
    }

    private void checkAndStartReady(Handler<AsyncResult<Void>> completer) {
        HttpTokenUtil.setJwtKey((String) configService.get(Config.JWT_ENCRYPT_KEY));
        whitelistService.refreshWhitelist(true);
        logger.debug("server launched successfully");
        completer.handle(Future.succeededFuture());
    }

    private void repeatingCheckAndStart(Handler<AsyncResult<Void>> completer) {
        vertx.setTimer(Constants.DEF_TIMER_TIME, event -> {
            checkAndStart(completer);
        });
    }

    @Override
    public void stop(Handler<AsyncResult<Void>> completer){}
}
