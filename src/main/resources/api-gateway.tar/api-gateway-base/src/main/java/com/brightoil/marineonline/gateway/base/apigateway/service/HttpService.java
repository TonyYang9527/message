package com.brightoil.marineonline.gateway.base.apigateway.service;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;
import io.vertx.reactivex.core.MultiMap;
import io.vertx.reactivex.core.buffer.Buffer;
import io.vertx.reactivex.ext.web.client.HttpResponse;

public interface HttpService{

    // do GET
    public void doGet(String reqId, String anonToken,  MultiMap headers, String host, int port, String uri, MultiMap params, Handler<AsyncResult<HttpResponse<Buffer>>> handler);

    // do POST
    public void doPost(String reqId, String anonToken, MultiMap headers, String host, int port, String uri, MultiMap params, Buffer body, Handler<AsyncResult<HttpResponse<Buffer>>> handler);

    public void doSend(String reqId, String anonToken, MultiMap headers, String host, int port, String uri, MultiMap params, Buffer body, Handler<AsyncResult<HttpResponse<Buffer>>> handler);
}
