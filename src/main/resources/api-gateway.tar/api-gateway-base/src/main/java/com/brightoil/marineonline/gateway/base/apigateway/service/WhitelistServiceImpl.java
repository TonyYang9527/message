package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.parser.RequestUrlParser;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.parser.RequestUrlParser;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.util.internal.ConcurrentSet;
import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;

@Singleton
public class WhitelistServiceImpl implements WhitelistService {

    @InjectLogger
    Logger logger;

    @Inject
    ConfigService configService;

    @Inject
    private HttpService httpUtil;

    private Semaphore whitelistSemaphore = new Semaphore(1);

    private String host;
    private String path;
    private int    port;
    private int    frequency;

    private ConcurrentHashMap<String, ConcurrentSet<String>> exactMatchCfg = new ConcurrentHashMap<String, ConcurrentSet<String>>();
    private ConcurrentHashMap<String, ConcurrentSet<String>> prefixMatchCfg = new ConcurrentHashMap<String, ConcurrentSet<String>>();

    public boolean init(){
        try{
            try{
                String uri = (String) configService.get(Config.ENV_WHITELIST_URI);
                int    frq = (int)    configService.get(Config.ENV_WHITELIST_FREQUENCY);

                RequestUrlParser parse = new RequestUrlParser(uri);
                this.host = parse.getHost();
                this.port = parse.getPort();
                this.path = parse.getPath();

                frequency = frq * 1000;
            }catch (Throwable ex){
                logger.error("init whitelist failure due to {}",ex.getMessage(), ex);
                return false;
            }
        }catch (Throwable ex){
            logger.error("init failure due to {}", ex.getMessage(), ex);
            return false;
        }
        return true;
    }

    public void refreshWhitelist(boolean success){
        if(whitelistSemaphore.tryAcquire()){
            VertxHolder.get().setTimer(frequency, new Handler<Long>() {
                public void handle(Long t) {
                    try{
                        retrieveWhitelist(e -> {
                            afterRefreshWhitelist(e.succeeded() && e.result() && e.cause() == null);
                        });
                    }catch (Throwable ex){
                        logger.error("retrieve whitelist failure due to {}", ex.getMessage(), ex);
                        afterRefreshWhitelist(false);
                    }
                }
            });
        }else{
            VertxHolder.get().setTimer(Constants.DEF_TIMER_TIME, new Handler<Long>() {
                public void handle(Long t) {
                    refreshWhitelist(true);
                }
            });
        }
    }

    private void afterRefreshWhitelist(boolean success) {
        whitelistSemaphore.release(1);
        refreshWhitelist(success);
    }

    public void retrieveWhitelist(Handler<AsyncResult<Boolean>> completer){
        httpUtil.doGet("whitelist", null, null, host, port, path, null, event -> {
            if(event.cause() != null){
                logger.error("refresh whitelist failure",event.cause());
                completer.handle(Future.failedFuture(event.cause()));
                return;
            }
            if(!event.succeeded()){
                logger.error("refresh whitelist not success");
                completer.handle(Future.succeededFuture(Boolean.FALSE));
                return;
            }
            if(event.result().statusCode() != HttpResponseStatus.OK.code()){
                logger.error("refresh whitelist not success");
                completer.handle(Future.succeededFuture(Boolean.FALSE));
                return;
            }
            JsonObject json = null;
            try{
                json = event.result().bodyAsJsonObject();
            }catch (Throwable ex){
                logger.error("refresh whitelist failure due to invalid response body", ex);
                completer.handle(Future.succeededFuture(Boolean.FALSE));
                return;
            }
            if(json == null || json.size() == 0){
                logger.error("refresh whitelist non-success due to empty body");
                completer.handle(Future.succeededFuture(Boolean.FALSE));
                return;
            }
            refresh(json);
            logWhitelist("service-uri", exactMatchCfg);
            logWhitelist("service-prefix", prefixMatchCfg);
            completer.handle(Future.succeededFuture(Boolean.TRUE));
        });
    }

    private void logWhitelist(String type, ConcurrentHashMap<String, ConcurrentSet<String>> map) {
        if(map == null || map.size() == 0){
            return;
        }
        map.entrySet().forEach(entry -> {
            String key = entry.getKey();
            ConcurrentSet<String> list = entry.getValue();
            if(list != null){
                list.stream().forEach(s -> {
                    logger.debug("white-list: {} > [{}][{}]", type, key, s);
                });
            }
        });
    }

    public void isResourceInWhitelist(String serviceName, int port, String uri, Handler<AsyncResult<Boolean>> completer){
        try{
            boolean ok = validate(serviceName, uri);
            logger.info("resource authorization [{}][{}] ==> [{}]", serviceName, uri, ok);
            completer.handle(Future.succeededFuture(ok));
        }catch (Throwable ex){
            logger.info("resource authorization [{}][{}] failed due to {}", serviceName, uri, ex.getMessage(), ex);
            completer.handle(Future.succeededFuture(false));
        }
    }

    private void refresh(JsonObject json) {
        json.spliterator().forEachRemaining(entry -> {
            Object obj = entry.getValue();
            if(obj == null){
                return;
            }
            JsonArray array = null;
            if(obj instanceof JsonArray){
                array = (JsonArray)obj;
            }
            if(array == null || array.size() == 0){
                return;
            }

            ConcurrentSet<String> prefix = new ConcurrentSet<String>();
            ConcurrentSet<String> exact = new ConcurrentSet<String>();

            array.iterator().forEachRemaining(o -> {
                if(o != null && o instanceof String){
                    String str = (String) o;
                    str = str.trim();
                    if(str.length() > 0) {
                        if(str.endsWith("*") && str.length() > 1) {
                            prefix.add(str.substring(0, str.length()-1));
                        }else{
                            exact.add(str);
                        }
                    }
                }
            });

            if(exact.size() > 0) {
                exactMatchCfg.put(entry.getKey(), exact);
            }
            if(prefix.size() > 0) {
                prefixMatchCfg.put(entry.getKey(), prefix);
            }
        });
    }

    private boolean validate(String serviceName, String uri) {
        if(serviceName.equalsIgnoreCase("192.168.48.110") || serviceName.equalsIgnoreCase("192.168.48.111") || serviceName.equalsIgnoreCase("192.168.48.109")){
            return true;
        }
        if(prefixMatchCfg.size() == 0 && exactMatchCfg.size() == 0){
            return false;
        }
        if(StringUtils.isBlank(serviceName) || StringUtils.isBlank(uri)){
            return false;
        }
        ConcurrentSet<String> uris = null;
        uris = prefixMatchCfg.get(serviceName);
        if(uris != null) {
            if (uris.stream().filter(s -> uri.startsWith(s)).findAny().isPresent()) {
                return true;
            }
        }
        uris = exactMatchCfg.get(serviceName);
        if(uris != null) {
            if (uris.stream().filter(s -> uri.equalsIgnoreCase(s)).findAny().isPresent()) {
                return true;
            }
        }
        return false;
    }
}
