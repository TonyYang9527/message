package com.brightoil.marineonline.gateway.base.apigateway.model;

public enum EventType {

    COM_HEARTBEAT(0),
    SELF_HEARTBEAT(1),
    BLACKLIST(2),
    LOGGING(3),
    REVALIDATE(4),
    PUSH_MESSAGE(5)
    ;
    private int code;

    EventType(int code){
        this.code = code;
    }
}
