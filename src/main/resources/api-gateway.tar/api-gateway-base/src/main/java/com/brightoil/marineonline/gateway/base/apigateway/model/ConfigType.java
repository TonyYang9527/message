package com.brightoil.marineonline.gateway.base.apigateway.model;

public enum ConfigType {

    STRING(0),
    INT(1),
    LONG(2);

    private int code;

    ConfigType(int code){
        this.code = code;
    }
}
