package com.brightoil.marineonline.gateway.base.apigateway.filter.filters;

import com.brightoil.marineonline.gateway.base.apigateway.filter.Filter;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;
import com.brightoil.marineonline.gateway.base.apigateway.filter.context.Security;
import com.brightoil.marineonline.gateway.base.apigateway.service.AnonTokenService;
import com.brightoil.marineonline.gateway.base.apigateway.service.AnonTokenService;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.scan.Order;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.scan.Order;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.netty.handler.codec.http.HttpResponseStatus;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

@Singleton
@Order(2)
public class UserAnonTokenFilter implements Filter<Security> {

    @InjectLogger
    Logger logger;

    @Inject
    AnonTokenService service;

    @Override
    public void doFilter(FilterConfig<Security> cfg) {
        try{
            Security ctx = cfg.get();
            /**
             * This filter will only response for request which does not have valid token with authenticate not required
             */
            if(ctx.isAuthRequired()){
                // token has confirmed to be valid, guest token not applicable for authenticate required request
                cfg.doFilter();
                return;
            }
            /**
             * if authentication is not required and have no valid token, then, return create a new guest
             */
            if(StringUtils.isNotBlank(ctx.getAuthToken())){
                // token has confirmed to be valid, second validation is not required
                cfg.doFilter();
                return;
            }
            service.createGuestToken(ctx.getRequestId(), e -> {
                if(e.cause() != null){
                    logger.error("[{}] - request guest token failed due to {}", ctx.getRequestId(), e.cause().getMessage());
                    ctx.response(HttpResponseStatus.PROXY_AUTHENTICATION_REQUIRED.code(), e.cause()).stop().doFilter();
                    return;
                }
                String token = e.result();
                if(StringUtils.isBlank(token)){
                    logger.debug("[{}] - request unsuccessful", ctx.getRequestId());
                    ctx.response(HttpResponseStatus.PROXY_AUTHENTICATION_REQUIRED.code(), null).stop().doFilter();
                    return;
                }
                logger.debug("[{}] - request succeed", ctx.getRequestId());
                ctx.setAnonToken(token).doFilter();
            });
        }catch (Throwable ex){
            logger.error("[{}] - guest token processing failed due to {}", ex.getMessage(), ex);
            cfg.get().response(HttpResponseStatus.BAD_GATEWAY.code(), ex).stop().doFilter();
        }
    }
}
