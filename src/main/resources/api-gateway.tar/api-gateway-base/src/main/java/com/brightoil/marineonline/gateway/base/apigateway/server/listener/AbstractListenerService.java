package com.brightoil.marineonline.gateway.base.apigateway.server.listener;

import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;
import com.brightoil.marineonline.gateway.base.apigateway.model.EventType;
import com.brightoil.marineonline.gateway.base.apigateway.service.ChannelEventService;
import com.brightoil.marineonline.gateway.base.apigateway.service.RedisService;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.util.EventUtil;
import io.lettuce.core.pubsub.RedisPubSubAdapter;
import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.json.JsonObject;
import io.vertx.reactivex.core.Vertx;
import org.slf4j.Logger;

public abstract class AbstractListenerService {

    private static final long MAX_ACKLEDGE_PERIOD = 360000l; // 6 minutes
    private static final long DEF_MONITOR_PERIOD = 300000l; // 5 minutes

    RedisPubSubAdapter<String, String> listener;

    long lastHeartbeatAckDttm = 0l;

    Vertx vertx;

    public boolean init(){
        try{
            vertx = VertxHolder.get();
            this.listener = new RedisPubSubAdapter<String, String>() {
                @Override
                public void message(String channel, String message) {
                    try{
                        getLogger().info("received channel event {}", message);
                        handleChannelEvent(message.trim());
                    }catch (Throwable ex){
                        getLogger().error("handle channel event message {} failure due to {}", message, ex.getMessage(), ex);
                    }
                }
            };
        }catch (Throwable ex){
            getLogger().error("init failure due to {}", ex.getMessage(), ex);
            return false;
        }
        return true;
    }

    public void registerListener(Handler<AsyncResult<Void>> completer) {
        Future future = Future.future();
        future.setHandler(event -> {
            sendingHeartBeat(e1 -> {
                startMonitor();
                completer.handle(Future.succeededFuture());
            });
        });
        doRegisterListener(future.completer());
    }

    private void startMonitor() {
        vertx.setTimer(DEF_MONITOR_PERIOD, e2 -> {
            if((System.currentTimeMillis() - lastHeartbeatAckDttm) <= MAX_ACKLEDGE_PERIOD) {
                // non-timeout
                sendingHeartBeat(e1 -> {
                    startMonitor();
                });
                return;
            }else{
                getLogger().debug("server have not receive heartbeat within frame on {}, register new listener now", getChannelName());
                // timeout
                getRedisService().unRegisterListener(getChannelName(), listener, e1 -> {
                    registerListener(event -> {
                        getLogger().debug("re-registering-listener on {} succeed", getChannelName());
                    });
                });
            }
        });
    }

    private void sendingHeartBeat(Handler<AsyncResult<Void>> completer) {
        getRedisService().publishMessage(getChannelName(), getHeartbeatEvent(), event -> {
            if(event.cause() != null){
                getLogger().error("sending heartbeat failed, waiting for next time to resend", event.cause());
            }
            if(event.succeeded()){
                getLogger().debug("sending heartbeat succeed");
            }
            completer.handle(Future.succeededFuture());
        });
    }

    private String getHeartbeatEvent() {
        EventType eventType = getHeartbeatEventType();
        // event data
        JsonObject jsonObject = new JsonObject();
        jsonObject.put(eventType.name(), String.valueOf(System.currentTimeMillis()));
        // event
        EventUtil event = new EventUtil();
        event.setEventType(eventType);
        event.setData(jsonObject);
        return event.encode();
    }


    private void doRegisterListener(Handler<AsyncResult<Void>> completer) {
        this.getRedisService().registerListener(getChannelName(), listener, event -> {
            if(event.cause() != null){
                getLogger().error("register redis {} listener failed due to {}, will try to register again", getChannelName(), event.cause().getMessage(), event.cause());
                continueRegisterListener(completer);
                return;
            }
            if(!event.succeeded()){
                getLogger().error("register redis {} listener failed due to {}, will try to register again", getChannelName(),event.cause());
                continueRegisterListener(completer);
                return;
            }
            getLogger().debug("register listener on {} succeed", getChannelName());
            completer.handle(Future.succeededFuture());
        });
    }

    private void continueRegisterListener(Handler<AsyncResult<Void>> completer) {
        VertxHolder.get().setTimer(Constants.DEF_TIMER_TIME, t -> {
            doRegisterListener(completer);
        });
    }

    public void handleChannelEvent(String event) {
        if(event == null || event.trim().length() == 0){
            return;
        }
        EventUtil channelEvent = EventUtil.decode(event);
        if(channelEvent == null){
            return;
        }
        getLogger().debug("received channel event {} : {}", channelEvent.getEventType().name(), channelEvent.getData());
        if(getHeartbeatEventType().name().equalsIgnoreCase(channelEvent.getEventType().name())){
            try{ lastHeartbeatAckDttm = System.currentTimeMillis(); }catch (Throwable ex){}
            return;
        }
        getChannelEventService().handleChannelEvent(channelEvent.getEventType(), channelEvent.getData());
    }

    protected abstract RedisService getRedisService();

    protected abstract ChannelEventService getChannelEventService();

    protected abstract Logger getLogger();

    protected abstract String getChannelName();

    protected abstract EventType getHeartbeatEventType();
}
