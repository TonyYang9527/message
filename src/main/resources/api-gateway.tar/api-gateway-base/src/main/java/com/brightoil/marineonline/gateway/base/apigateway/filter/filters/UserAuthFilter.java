package com.brightoil.marineonline.gateway.base.apigateway.filter.filters;

import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.apigateway.filter.Filter;
import com.brightoil.marineonline.gateway.base.apigateway.filter.FilterConfig;
import com.brightoil.marineonline.gateway.base.apigateway.filter.context.Security;
import com.brightoil.marineonline.gateway.base.apigateway.service.AuthService;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigService;
import com.brightoil.marineonline.gateway.base.apigateway.service.AuthService;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigService;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.netty.handler.codec.http.HttpResponseStatus;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

@Singleton
public class UserAuthFilter implements Filter<Security> {

    @InjectLogger
    Logger logger;

    @Inject
    ConfigService configService;

    @Inject
    AuthService service;

    private String env;

    public boolean init(){
        try{
            env = (String) configService.get(Config.ENV);
        }catch (Throwable ex){
            logger.error("init failure due to {}", ex.getMessage(), ex);
            return false;
        }
        return true;
    }

    /**
     * if the user has a valid token
     *  - isGuest: true / false
     *  - gateway will directly response client if it is an guest token
     *  - gateway will call user centre to perform verification if the token is not a guest token
     */
    public void doFilter(FilterConfig<Security> cfg) {
        try {
            Security ctx = cfg.get();
            if(!ctx.isAuthRequired()){
                cfg.doFilter();
                return;
            }
            // authentication requires: service name, service uri, and token
            boolean valid = true;
            if(StringUtils.isBlank(ctx.getAuthToken())){
                valid = false;
                return;
            }
            if(ctx.isGuestToken()){
                valid = false;
                return;
            }
            if(StringUtils.isBlank(ctx.getServiceName())){
                valid = false;
                return;
            }
            if(StringUtils.isBlank(ctx.getServiceURI())){
                valid = false;
            }
            if(!valid){
                logger.debug("[{}] - no auth details", ctx.getRequestId());
                ctx.response(HttpResponseStatus.NON_AUTHORITATIVE_INFORMATION.code(), null).stop().doFilter();
                return;
            }
            service.authenticate(ctx.getRequestId(), ctx.getServiceName(), ctx.getServiceURI(), ctx.getAuthToken(), e -> {
                if (e.cause() != null) {
                    logger.error("[{}] - auth error due to {}", ctx.getRequestId(), e.cause().getMessage(), e);
                    ctx.response(HttpResponseStatus.PROXY_AUTHENTICATION_REQUIRED.code(), e.cause()).stop().doFilter();
                    return;
                }
                Integer status = e.result();
                if(status == null){
                    logger.debug("[{}] - auth failed due to no status return", ctx.getRequestId());
                    ctx.response(HttpResponseStatus.PROXY_AUTHENTICATION_REQUIRED.code(), null).stop().doFilter();
                    return;
                }
                if(status.intValue() != HttpResponseStatus.OK.code()){
                    logger.debug("[{}] - auth failed due to auth return status {}", ctx.getRequestId(), status.intValue());
                    ctx.response(status.intValue(), null).stop().doFilter();
                    return;
                }
                cfg.doFilter();
            });
        }catch (Throwable e){
            try {
                logger.error("[{}] - auth error due to {}", cfg.get().getRequestId(), e.getMessage(), e);
                cfg.get().response(HttpResponseStatus.PROXY_AUTHENTICATION_REQUIRED.code(), e).stop().doFilter();
                return;
            }catch (Throwable ex){}
        }
    }
}
