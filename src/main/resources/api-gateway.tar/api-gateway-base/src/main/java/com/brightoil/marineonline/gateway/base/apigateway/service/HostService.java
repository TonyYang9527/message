package com.brightoil.marineonline.gateway.base.apigateway.service;

public interface HostService {

    public String getHost();

    public String getHostAddr();

    public String getHostName();
}
