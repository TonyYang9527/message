package com.brightoil.marineonline.gateway.base.apigateway.filter;

public class FilterConfig<T extends Delegate> {

    private FilterChain chain      = null;
    private T           proxy      = null;

    private int         index      = 0;
    private long        start      = 0l;

    private boolean     stop       = false;
    private boolean     running    = false;

    private Filter      filter     = null;

    private FilterConfigCallback  handler;

    public FilterConfig(T proxy, FilterChain chain, FilterConfigCallback handler){
        this.proxy = proxy;
        this.chain = chain;
        this.handler = handler;
        this.proxy.init(this);
    }

    public FilterConfig doFilter(){
        chain.doFilter(this);
        return this;
    }

    public int autoRotate() {
        return index++;
    }

    public FilterConfig<T> reset() {
        if(this.proxy != null) {
            this.proxy.reset();
        }
        this.index                 = 0;
        this.start                 = 0l;
        this.stop                  = false;
        this.running               = false;
        this.filter                = null;
        return this;
    }

    public void release(){
        handler.release(this);
    }

    public T get() {
        return proxy;
    }

    public boolean isStopping() {
        return stop;
    }

    public Filter filter() {
        return filter;
    }

    public FilterChain chain() {
        return chain;
    }

    public FilterConfig stop() {
        this.stop = true;
        return this;
    }

    public FilterConfig started(Filter filter){
        this.running   = true;
        this.filter    = filter;
        this.start     = System.currentTimeMillis();
        return this;
    }

    public FilterConfig stopped() {
        this.start     = 0l;
        this.filter    = null;
        this.running   = false;
        return this;
    }

    /***
    private void tracking(Filter nextFilter) {
        if(this.filter == null && nextFilter == null){
            /////** no such case
            /////return;
        }
        if(this.filter == null && nextFilter != null){
            /////** initial start
            /////return;
        }
        if(this.filter != null && nextFilter != null){
            /////** before next filter to be executed
        }
        if(this.filter != null && nextFilter == null){
            ////** before last filter to be executed
        }
        logger.info("[Performance Tracking] - [{}] - Filter: {} - Spent: {} ms",
                proxy.getRequestId(),
                filter.getClass().getSimpleName(),
                System.currentTimeMillis() - this.start
        );
    }
    ***/
}
