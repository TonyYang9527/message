package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;
import com.brightoil.marineonline.gateway.base.apigateway.model.ConfigType;
import com.brightoil.marineonline.gateway.base.apigateway.model.Property;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.scan.Order;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.scan.Order;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

import javax.inject.Named;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

@Singleton
@Order(1)
public class ConfigServiceImpl implements ConfigService {

    private static final String PROTOCAL_FILE = "file://";

    @InjectLogger
    Logger logger;

    @Inject()
    @Named("defaultConfig")
    Config config;

    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    public void setConfig(Config config) {
        this.config = config;
    }

    private ConcurrentHashMap<String, Object> cache = new ConcurrentHashMap<>();

    private String getConfigFileLocation(String configName, String defaultValue){
        String val = System.getenv(configName);
        if(val != null && val.trim().length() > 0){
            logger.info("environment parameter [{}] found with value {}", configName, val);
            return val;
        }
        val = System.getProperty(configName);
        if(val != null && val.trim().length() > 0){
            logger.info("environment property [{}] found with value {}", configName, val);
            return val;
        }
        logger.info("environment parameter [{}] not found, return default value {}", configName, defaultValue);
        return defaultValue;
    }

    public boolean init(){
        boolean success = true;
        try{
            initEnvConfig(config.getLocalProperties(),  getConfigFileLocation(Config.CONFIG_FILE_LOCAL,    "/config.properties"));
            initEnvConfig(config.getDefaultProperties(), getConfigFileLocation(Config.CONFIG_FILE_GLOBAL,   "/global.properties"));
            initEnvConfig(config.getLocalProperties(),  getConfigFileLocation(Config.CONFIG_FILE_CUSTOME,  "/custom.properties"));
            initEnvConfig(config.getDefaultProperties(), getConfigFileLocation(Config.CONFIG_FILE_CUSTOME,  "/custom.properties"));
            initEnvConfig(config.getLocalProperties(),  getConfigFileLocation(Config.CONFIG_FILE_ADDITION, "/addition.properties"));
            initEnvConfig(config.getDefaultProperties(), getConfigFileLocation(Config.CONFIG_FILE_ADDITION, "/addition.properties"));
            if(checkConfig(config.getDefaultProperties())){
                success = false;
            }
            if(checkConfig(config.getLocalProperties())){
                success = false;
            }
            if(success){
                logger.info("configuration initialized successfully.");
            }else{
                logger.error("configuration initialization failure.");
            }
        }catch (Throwable ex){
            logger.error("init failure due to {}", ex.getMessage(), ex);
            return false;
        }
        return success;
    }

    private boolean checkConfig(Property[] propertyList) {
        boolean hasError = false;
        if(propertyList != null) {
            for (Property property : propertyList) {
                if(StringUtils.isBlank(property.getName())){
                    continue;
                }
                if(cache.containsKey(property.getName())){
                    if(property.getName().startsWith(Constants.CONFIG_SECRET)){
                        logger.info("configuration [{}]=[{}]", property.getName(), "<Credential>");
                    }else{
                        logger.info("configuration [{}]=[{}]", property.getName(), cache.get(property.getName()));
                    }
                }else{
                    hasError = true;
                    logger.error("configuration [{}] not found", property.getName());
                }
            }
        }else{
            hasError = true;
        }
        return hasError;
    }

    private int initEnvConfig(Property[] propertyList, String env){
        int propertyCount = 0;
        Map<String, String> config = null;
        try {
            if(env != null && env.trim().length() > 0) {
                File file = new File(env);
                if (file.exists() && file.canRead()) {
                    file = null;
                    config = loadConfig(logger, env);
                }
            }
        } catch (Throwable e) {
            logger.error("loading environment configuration file {} failure", env, e);
            return 0;
        }
        if(propertyList != null) {
            for (Property property : propertyList) {
                propertyCount += configProperty(property, config);
            }
        }
        return propertyCount;
    }

    private int configProperty(Property property, Map<String, String> config) {
        if(config == null || config.size() == 0){
            return 0;
        }
        String     name = property.getName();
        ConfigType type = property.getType();
        if(StringUtils.isBlank(name)){
            return 0;
        }
        name = name.trim();
        String val = config.get(name);
        if(StringUtils.isBlank(val)){
            //logger.error(String.format("loading configuration [%s] not found.", name));
            return 0;
        }
        val  = val.trim();
        try{
            switch (type){
                case INT:    cache.put(name, Integer.parseInt(val)); break;
                case LONG:   cache.put(name, Long.parseLong(val));   break;
                case STRING: cache.put(name, val);                   break;
            }
        }catch (Throwable ex){
            logger.error(String.format("loading configuration [%s] is not properly configured, issue: %s", name, ex.getMessage()), ex);
            return 0;
        }
        //logger.info(String.format("loading configuration [%s]=[%s]", name, val));
        return 1;
    }

    private static Map<String, String> loadConfig(Logger logger, String path) throws Throwable {
        Map<String, String> map = new HashMap<>();
        Properties prop = new Properties();
        InputStream input = null;
        try {
            File file = new File(path);
            if(!(file.exists() && file.canRead())){
                logger.error("configuration file {} not found or cannot read", path);
                return map;
            }
            input = new FileInputStream(file);
            prop.load(input);
            prop.forEach((k, v) -> {
                if(k != null && v != null) {
                    String key = (String) k;
                    String val = (String) v;
                    if(val.indexOf(PROTOCAL_FILE) == 0){
                        val = loadFile(logger, key, val.substring(PROTOCAL_FILE.length()));
                    }
                    if(val != null){
                        map.put(key, val);
                    }
                }
            });
            return map;
        } catch (Throwable ex) {
            throw ex;
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (Throwable e) {}
            }
        }
    }

    private static String loadFile(Logger logger, String key, String val) {
        logger.info("reading configuration from reference file {} for {}", key, val);
        Path path = Paths.get(val);
        if(!Files.exists(path, LinkOption.NOFOLLOW_LINKS)){
            logger.error("configuration reference file {} not found or cannot read", val);
            return null;
        }
        List<String> list = null;
        try {
            list = Files.readAllLines(path);
        } catch (IOException e) {
            logger.error("configuration reference file {} failed due to {}", val, e.getMessage());
            return null;
        }
        if(list != null && list.size() > 0){
            for(String str : list){
                if(StringUtils.isNotBlank(str)){
                    return str;
                }
            }
        }
        return null;
    }

    @Override
    public Object get(String key) {
        return cache.get(key);
    }
}
