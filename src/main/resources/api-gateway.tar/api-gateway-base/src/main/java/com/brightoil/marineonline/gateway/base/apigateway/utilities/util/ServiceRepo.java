package com.brightoil.marineonline.gateway.base.apigateway.utilities.util;

import com.google.inject.Injector;

public class ServiceRepo {

    private static Injector injector;

    public static void set(Injector injector){
        if(ServiceRepo.injector == null) {
            ServiceRepo.injector = injector;
        }
    }

    public static Object get(Class clzz) {
        return injector.getInstance(clzz);
    }
}
