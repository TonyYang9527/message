package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.common.Constants;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.vertx.core.http.HttpHeaders;
import io.vertx.reactivex.core.MultiMap;
import io.vertx.reactivex.core.http.HttpServerResponse;
import io.vertx.reactivex.ext.web.RoutingContext;
import io.vertx.reactivex.ext.web.handler.sockjs.SockJSSocket;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

@Singleton
public class HttpHeaderServiceImpl implements HttpHeaderService {

    private static final String GATEWAY_PREFIX = "/api/";
    private static final String X_FORWARD_FOR  = "X-Forwarded-For";
    private static final String X_REAL_IP = "X-Real-Ip";
    private static final String CONTENT_TYPE_TEXT_NAME  = "Content-Type";
    private static final String CONTENT_TYPE_TEXT_VALUE = "text/plain; charset=utf-8";

    private static final String allowHeaders = "Authorization,Content-Type";
    private static final String allowMethods = "GET,HEAD,POST,PUT,DELETE,OPTIONS,PATCH";

    private static Predicate<Map.Entry<String, String>> HEADER_RESPONSIBLE = null;
    private static Predicate<Map.Entry<String, String>> HEADER_FORWARDABLE = null;
    private static Set<String> RESTRICTED_HEADERS = null;

    @InjectLogger
    Logger logger;

    @Inject
    HostService hostService;

    static {
        RESTRICTED_HEADERS =
                Stream.of(
                        HttpHeaderNames.DATE.toString().toLowerCase(),
                        HttpHeaderNames.COOKIE.toString().toLowerCase(),
                        HttpHeaderNames.SET_COOKIE.toString().toLowerCase(),
                        HttpHeaderNames.CONNECTION.toString().toLowerCase(),
                        HttpHeaderNames.IF_MODIFIED_SINCE.toString().toLowerCase()
                )
                .map(CharSequence::toString)
                .collect(Collectors.toSet());

        HEADER_FORWARDABLE =
                e -> e.getKey().toLowerCase().contentEquals(HttpHeaderNames.AUTHORIZATION.toString().toLowerCase())
                        && e.getValue().startsWith("Basic ")
                        || !RESTRICTED_HEADERS.contains(e.getKey().toLowerCase());

        HEADER_RESPONSIBLE =
                e -> !RESTRICTED_HEADERS.contains(e.getKey().toLowerCase());
    }

    @Override
    public void copyErrorResponseHeader(HttpServerResponse res) {
        if(res.closed() || res.ended()){
           return;
        }
        res.headers().set(CONTENT_TYPE_TEXT_NAME, CONTENT_TYPE_TEXT_VALUE);
    }

    public void copyRequestHeader(String reqId, String anonToken, MultiMap copyFROM, MultiMap copyTO) {
        if(copyTO == null){
            return;
        }
        copyTO.clear();

        if(copyFROM != null){
            StreamSupport.stream(copyFROM.getDelegate().spliterator(), false)
                    .filter(HEADER_FORWARDABLE)
                    .forEach(s -> {
                        if(s.getKey() != null) {
                            if (s.getValue() != null && s.getValue().trim().length() > 0) {
                                copyTO.add(s.getKey(), s.getValue());
                                logger.debug("[{}] - request header [{}={}]", reqId, s.getKey(), s.getValue());
                            }
                        }
                    });
        }

        // referer
        String referer = getAppRefer(copyTO.get(HttpHeaders.REFERER.toString()));
        if(StringUtils.isNotBlank(referer)) {
            copyTO.add(HttpHeaders.REFERER.toString(), referer);
            logger.debug("[{}] - request header [{}={}]", reqId, HttpHeaders.REFERER.toString(), referer);
        }

        // x-forward-for
        String host = copyTO.get(HttpHeaders.HOST.toString());
        if(StringUtils.isNotBlank(host)) {
            String xforward = getXForwardFor(host, copyTO.get(X_FORWARD_FOR));
            copyTO.add(X_FORWARD_FOR, xforward);
            logger.debug("[{}] - request header [{}={}]", reqId, X_FORWARD_FOR, xforward);
        }

        // check token in response headers
        if(!copyTO.contains(Constants.HEADER_PROPERTY_HTTP_USER_TOKEN)){
            if(StringUtils.isNotBlank(anonToken)){
                copyTO.set(Constants.HEADER_PROPERTY_HTTP_USER_TOKEN, anonToken);
                logger.debug("[{}] - request header [{}={}]", reqId, Constants.HEADER_PROPERTY_HTTP_USER_TOKEN, anonToken);
            }
        }
    }

    private String getXForwardFor(String host, String val) {
        if(StringUtils.isBlank(val)){
            return String.format("%s, %s", host, hostService.getHostAddr());
        }
        return String.format("%s, %s", val, hostService.getHostAddr());
    }

    private String getAppRefer(String val) {
        if(val == null){
            return val;
        }
        int index = val.indexOf(GATEWAY_PREFIX);
        if(index == -1){
            return null;
        }
        val = val.substring(index+GATEWAY_PREFIX.length());
        if(val == null || val.length() == 0){
            return null;
        }
        val = String.format("http://%s",val);
        return val;
    }

    public void copyResponseHeader(String reqId, String anonToken, MultiMap copyFROM, MultiMap copyTO, boolean all) {
        AtomicReference<String> str = new AtomicReference<String>();
        if(all) {
            StreamSupport.stream(copyFROM.getDelegate().spliterator(), false)
                    .filter(HEADER_RESPONSIBLE)
                    .forEach(s -> {
                        if(s.getValue() != null && s.getValue().trim().length() > 0){
                            copyTO.add(s.getKey(), s.getValue());
                            logger.debug("[{}] - response header [{}={}]", reqId, s.getKey(), s.getValue());
                        }
                        if(s.getKey().equalsIgnoreCase(Constants.HEADER_PROPERTY_HTTP_USER_TOKEN)){
                            str.set(s.getKey());
                        }
                    });
        }
        // check content-type
        String contentType = copyFROM.get("Content-Type");
        if(StringUtils.isBlank(contentType)) {
            contentType = "text/html;charset=utf-8";
        }
        copyTO.set("Content-Type", contentType);
        // check token in response headers
        if(str.get() != null && str.get().length() > 0) {
            copyTO.remove(str.get());
        }
        if(StringUtils.isNotBlank(anonToken)){
            copyTO.set(Constants.HEADER_PROPERTY_HTTP_USER_TOKEN, anonToken);
            logger.debug("[{}] - response header [{}={}]", reqId, Constants.HEADER_PROPERTY_HTTP_USER_TOKEN, anonToken);
        }
    }

    public void allowResponseHeader(String reqId, MultiMap copyTO) {
        allowResponseHeader(reqId,null, copyTO);
    }

    public void allowResponseHeader(String reqId, MultiMap copyFROM, MultiMap copyTO) {
        copyTO.set("Allow", allowMethods);
        copyTO.set("Pragma", "no-cache");
        copyTO.set("Cache-Control", "no-cache");
        copyTO.set("Access-Control-Max-Age", "300");
        copyTO.set("Access-Control-Allow-Origin", "*");
        copyTO.set("Access-Control-Allow-Methods",  allowMethods);
        copyTO.set("Access-Control-Expose-Headers", allowHeaders);
        copyTO.set("Access-Control-Allow-Headers",  allowHeaders);
    }

    @Override
    public String getRemoteHost(RoutingContext ctx) {
        String ips = null;
        ips = ctx.request().getHeader(X_REAL_IP);
        if(StringUtils.isNotBlank(ips)){
            return getRemoteHost(ips);
        }
        ips = ctx.request().getHeader(X_FORWARD_FOR);
        if(StringUtils.isNotBlank(ips)){
            return getRemoteHost(ips);
        }
        return ctx.request().remoteAddress().host();
    }

    @Override
    public String getRemoteHost(SockJSSocket ctx) {
        if(ctx == null || ctx.getDelegate() == null || ctx.getDelegate().headers() == null){
            return null;
        }
        String ips = null;
        ips = ctx.getDelegate().headers().get(X_REAL_IP);
        if(StringUtils.isNotBlank(ips)){
            return getRemoteHost(ips);
        }
        ips = ctx.getDelegate().headers().get(X_FORWARD_FOR);
        if(StringUtils.isNotBlank(ips)){
            return getRemoteHost(ips);
        }
        return ctx.getDelegate().remoteAddress().host();
    }

    private String getRemoteHost(String xips) {
        int idx = xips.indexOf(",");
        if(idx == -1){
            return xips.trim();
        }
        return xips.substring(0, idx);
    }
}
