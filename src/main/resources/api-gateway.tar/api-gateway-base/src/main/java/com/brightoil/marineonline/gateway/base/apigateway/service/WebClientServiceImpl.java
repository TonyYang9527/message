package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.Gateway;
import com.brightoil.marineonline.gateway.base.apigateway.model.CacheObject;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Singleton;
import io.vertx.core.http.HttpClientOptions;
import io.vertx.ext.web.client.WebClientOptions;
import io.vertx.reactivex.core.Vertx;
import io.vertx.reactivex.core.http.HttpClient;
import io.vertx.reactivex.ext.web.client.WebClient;
import org.slf4j.Logger;

import java.util.concurrent.ConcurrentLinkedQueue;

@Singleton
public class WebClientServiceImpl implements WebClientService {

    @InjectLogger
    Logger logger;

    private static final long MAX_CACHED_SIZE = 6000;
    private static final long MAX_CACHED_DURATION = 60000;

    private static final int TIME = 150000;

    private ConcurrentLinkedQueue<CacheObject<WebClient>> tempWebClientList = new ConcurrentLinkedQueue<>();
    private ConcurrentLinkedQueue<CacheObject<HttpClient>> tempHttpClientList = new ConcurrentLinkedQueue<>();
    private ConcurrentLinkedQueue<CacheObject<WebClient>> webClientList = new ConcurrentLinkedQueue<>();
    private ConcurrentLinkedQueue<CacheObject<HttpClient>> httpClientList = new ConcurrentLinkedQueue<>();

    private WebClientOptions webClientOptions;
    private HttpClientOptions httpClientOptions;

    private Vertx vertx;

    public boolean init(){
        webClientOptions = new WebClientOptions();
        configHttpClientOptions(webClientOptions);
        httpClientOptions = new HttpClientOptions();
        configHttpClientOptions(httpClientOptions);
        vertx = VertxHolder.get();
        listening();
        return true;
    }

    private void listening() {
       try{
           vertx.setTimer(TIME, event -> {
               try{
                   logger.debug("webclient-pool:{}, httpclient-pool:{} ", webClientList.size(), httpClientList.size());
                   listening();
               }catch (Throwable ex){
                   listening();
               }
           });
       }catch (Throwable ex){
           listening();
       }
    }

    private void configHttpClientOptions(HttpClientOptions options) {
        options.setTryUseCompression(Gateway.HttpClientOptions_TryUseCompression);
        options.setMaxPoolSize(Gateway.HttpClientOptions_MaxPoolSize);
        options.setIdleTimeout(Gateway.HttpClientOptions_IdleTimeout);
        options.setKeepAlive(Gateway.HttpClientOptions_KeepAlive);
        options.setTcpKeepAlive(Gateway.HttpClientOptions_TcpKeepAlive);
        options.setLogActivity(Gateway.HttpClientOptions_LogActivity);
    }

    public WebClient getWebClient(){
        CacheObject<WebClient> webClient = webClientList.poll();
        if(webClient != null){
            tempWebClientList.add(webClient);
            if(System.currentTimeMillis() - webClient.getCachedTime() < MAX_CACHED_DURATION){
                return webClient.getObj();
            }
            webClient.set(null, 0l);
        }
        return WebClient.create(vertx);
    }

    public void retWebClient(WebClient client){
        if(webClientList.size() > MAX_CACHED_SIZE){
            return;
        }
        if(client != null){
            CacheObject<WebClient> webClient = tempWebClientList.poll();
            if(webClient == null){
                webClient = new CacheObject<>();
            }
            webClient.set(client, System.currentTimeMillis());
            webClientList.add(webClient);
        }
    }

    public HttpClient getHttpClient(){
        CacheObject<HttpClient> httpClient = httpClientList.poll();
        if(httpClient != null){
            tempHttpClientList.add(httpClient);
            if(System.currentTimeMillis() - httpClient.getCachedTime() < MAX_CACHED_DURATION){
                return httpClient.getObj();
            }
            httpClient.set(null, 0l);
        }
        return vertx.createHttpClient(httpClientOptions);
    }

    public void retHttpClient(HttpClient client){
        if(httpClientList.size() > MAX_CACHED_SIZE){
            return;
        }
        if(client != null){
            CacheObject<HttpClient> httpClient = tempHttpClientList.poll();
            if(httpClient == null){
                httpClient = new CacheObject<>();
            }
            httpClient.set(client, System.currentTimeMillis());
            httpClientList.add(httpClient);
        }
    }
}
