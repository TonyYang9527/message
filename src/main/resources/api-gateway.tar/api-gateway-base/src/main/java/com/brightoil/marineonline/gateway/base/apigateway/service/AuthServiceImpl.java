package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.utilities.parser.RequestUrlParser;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.parser.RequestUrlParser;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.reactivex.core.MultiMap;
import io.vertx.reactivex.core.buffer.Buffer;
import io.vertx.reactivex.ext.web.client.HttpResponse;
import org.slf4j.Logger;

@Singleton
public class AuthServiceImpl implements AuthService {

    @InjectLogger
    Logger logger;

    @Inject
    ConfigService configService;

    @Inject
    private HttpService httpUtil;

    private int         port;
    private String      host;
    private String      path;
    private boolean     enabled;

    public boolean init(){
        try{
            String enabled  = (String) configService.get(Config.ENV_AUTH_ENABLED);
            String uri      = (String) configService.get(Config.ENV_AUTH);

            RequestUrlParser parse = new RequestUrlParser(uri);
            this.enabled    = ((enabled != null && (enabled.equalsIgnoreCase("Yes") || enabled.equalsIgnoreCase("True"))));
            this.host       = parse.getHost();
            this.port       = parse.getPort();
            this.path       = parse.getPath();
        }catch (Throwable ex){
            logger.error("init failure due to {}", ex.getMessage(), ex);
            return false;
        }
        return true;
    }

    @Override
    public void authenticate(String reqId, String serviceName, String uri, String token, Handler<AsyncResult<Integer>> completer) {
        try {
            MultiMap headers = MultiMap.caseInsensitiveMultiMap();
            headers.set("authorization", token);
            if (serviceName != null && uri != null) {
                headers.set("service-name", serviceName);
                headers.set("service-uri", uri);
            }
            httpUtil.doGet(reqId, null, headers, host, port, path, null, event -> {
                if (event.cause() != null) {
                    completer.handle(Future.failedFuture(event.cause()));
                    return;
                }
                HttpResponse<Buffer> response = event.result();
                if (response == null) {
                    completer.handle(Future.succeededFuture(HttpResponseStatus.SERVICE_UNAVAILABLE.code()));
                    return;
                }
                completer.handle(Future.succeededFuture(response.statusCode()));
            });
        }catch (Throwable ex){
            completer.handle(Future.failedFuture(ex));
        }
    }
}
