package com.brightoil.marineonline.gateway.base.apigateway.service;

import io.vertx.reactivex.core.http.HttpClient;
import io.vertx.reactivex.ext.web.client.WebClient;

public interface WebClientService {

    public WebClient getWebClient();

    public void retWebClient(WebClient client);

    public HttpClient getHttpClient();

    public void retHttpClient(HttpClient client);
}
