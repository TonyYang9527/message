package com.brightoil.marineonline.gateway.base.apigateway.filter;

public interface FilterConfigCallback {

    <T extends Delegate> void release(FilterConfig<T> filterConfig);
}
