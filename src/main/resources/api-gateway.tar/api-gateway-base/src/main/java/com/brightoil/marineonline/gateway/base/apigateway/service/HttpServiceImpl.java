package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.http.HttpMethod;
import io.vertx.reactivex.core.MultiMap;
import io.vertx.reactivex.core.buffer.Buffer;
import io.vertx.reactivex.ext.web.client.HttpRequest;
import io.vertx.reactivex.ext.web.client.HttpResponse;
import io.vertx.reactivex.ext.web.client.WebClient;
import io.vertx.reactivex.ext.web.codec.BodyCodec;
import org.slf4j.Logger;

@Singleton
public class HttpServiceImpl implements HttpService {

    @InjectLogger
    Logger logger;

    @Inject
    WebClientService clientService;

    @Inject
    HttpHeaderService headerService;

    @Override
    public void doGet(String reqId, String anonToken, MultiMap headers, String host, int port, String uri, MultiMap params, Handler<AsyncResult<HttpResponse<Buffer>>> handler) {
        try{
            WebClient client = clientService.getWebClient();
            HttpRequest<Buffer> request = client.request(HttpMethod.GET, port, host, uri);
            headerService.copyRequestHeader(reqId, anonToken, headers, request.headers());
            if(params != null && params.size() > 0){
                params.names().stream().forEach(s -> {
                    request.addQueryParam(s, params.get(s));
                });
            }
            request.rxSend().subscribe(response -> {
                clientService.retWebClient(client);
                handler.handle(Future.succeededFuture(response));
            }, e -> {
                handler.handle(Future.failedFuture(e));
            });
        }catch (Throwable e){
            handler.handle(Future.failedFuture(e));
        }
    }

    @Override
    public void doPost(String reqId, String anonToken, MultiMap headers, String host, int port, String uri, MultiMap params, Buffer body, Handler<AsyncResult<HttpResponse<Buffer>>> handler) {
        try{
            WebClient client = clientService.getWebClient();
            HttpRequest<Buffer> request = client.request(HttpMethod.POST, port, host, uri).as(BodyCodec.buffer());
            headerService.copyRequestHeader(reqId, anonToken, headers, request.headers());
            if(params != null && params.size() > 0){
                params.names().parallelStream().forEach(s -> {
                    request.addQueryParam(s, params.get(s));
                });
            }
            request.rxSendBuffer(body).subscribe(response -> {
                clientService.retWebClient(client);
                handler.handle(Future.succeededFuture(response));
            }, e -> {
                handler.handle(Future.failedFuture(e));
            });
        }catch (Throwable e){
            handler.handle(Future.failedFuture(e));
        }
    }

    @Override
    public void doSend(String reqId, String anonToken, MultiMap headers, String host, int port, String uri, MultiMap params, Buffer body, Handler<AsyncResult<HttpResponse<Buffer>>> handler) {
        try{
            WebClient client = clientService.getWebClient();
            HttpRequest<Buffer> request = client.request(HttpMethod.POST, port, host, uri);
            headerService.copyRequestHeader(reqId, anonToken, headers, request.headers());
            if(params != null && params.size() > 0){
                params.names().forEach(s -> {
                    request.addQueryParam(s, params.get(s));
                });
            }
            request.rxSendBuffer(body).subscribe(response -> {
                clientService.retWebClient(client);
                handler.handle(Future.succeededFuture(response));
            }, throwable -> {
                logger.error("{} sending message [{}] to service [{}:{}] is unsuccessful due to {}", reqId, body, uri, port, throwable.getMessage());
                handler.handle(Future.failedFuture(throwable));
            });
        }catch (Throwable e){
            handler.handle(Future.failedFuture(e));
        }
    }
}
