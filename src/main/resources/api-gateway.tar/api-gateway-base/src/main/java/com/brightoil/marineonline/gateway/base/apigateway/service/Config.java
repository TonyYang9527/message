package com.brightoil.marineonline.gateway.base.apigateway.service;


import com.brightoil.marineonline.gateway.base.apigateway.model.Property;
import com.brightoil.marineonline.gateway.base.apigateway.model.Property;

public interface Config {

    String CONFIG_FILE_LOCAL    = "env.local";
    String CONFIG_FILE_GLOBAL   = "env.global";
    String CONFIG_FILE_CUSTOME  = "env.custom";
    String CONFIG_FILE_ADDITION = "env.addition";

    /**--------------------------------------------------------------------------------------------------------------**/
    /**  Global configuration properties                                                                             **/
    /**--------------------------------------------------------------------------------------------------------------**/
    String ENV                  = "env.name";
    String SERVER_PORT          = "server.port";

    String MARIADB_HOST         = "db.mariadb.host.ip";
    String MARIADB_PORT         = "db.mariadb.host.port";
    String MARIADB_USER         = "db.mariadb.user";
    String MARIADB_CREDENTIAL   = "db.mariadb.password";

    String MQ_HOST              = "mq.host";
    String MQ_PORT              = "mq.port";
    String MQ_USER              = "mq.user";
    String MQ_CREDENTIAL        = "mq.password";

    String REDIS_IPS            = "db.redis.host.ips";
    String REDIS_PORTS          = "db.redis.host.ports";


    public Property[] getDefaultProperties();



    /**--------------------------------------------------------------------------------------------------------------**/
    /**  Local configuration properties                                                                              **/
    /**--------------------------------------------------------------------------------------------------------------**/

    String ENV_ROUTING_API          = "env.api.gateway.routing.api";
    String ENV_ROUTING_LOG          = "env.api.gateway.routing.detailed.logging";
    String ENV_ROUTING_BLACKLIST    = "env.api.gateway.routing.blacklist";
    String ENV_ROUTING_HTTP         = "env.api.gateway.routing.http";
    String ENV_ROUTING_WEBSOCKET    = "env.api.gateway.routing.websocket";
    String ENV_ROUTING_DISTRIBUTE   = "env.api.gateway.routing.distribute";
    String ENV_COMMON_LISTENER      = "env.api.gateway.required.common.listener";
    String ENV_SELF_LISTENER        = "env.api.gateway.required.self.listener";
    String ENV_CHANNEL              = "env.api.gateway.redis.channel";
    String ENV_AUTH                 = "env.api.gateway.auth.uri";


    String ENV_AUTH_ENABLED         = "env.api.gateway.auth.enabled";
    String ENV_GUEST_TOKEN          = "env.api.gateway.guest.token.uri";
    String ENV_WHITELIST_URI        = "env.api.gateway.whitelist.uri";
    String ENV_WHITELIST_FREQUENCY  = "env.api.gateway.whitelist.frequency";
    String ENV_SOCKJS_LIB           = "env.api.gateway.sockjs.lib.uri";
    String ENV_SOCKJS_HEARTBEAT     = "env.api.gateway.sockjs.heartbeat";

    String ENV_WEBSOCKET_SESSION_TIME_TO_LIVE
                                    = "env.api.gateway.websocket.time.to.live";
    String ENV_WEBSOCKET_SESSION_PREFIX
                                    = "env.api.gateway.websocket.session.prefix";

    String REDIS_TIMEOUT            = "env.api.gateway.redis.timeout";
    String REDIS_DATABASE           = "env.api.gateway.redis.database";
    String REDIS_MASTER_ID          = "env.api.gateway.redis.masterId";

    String JWT_ENCRYPT_KEY          = "secret.jwt.encrypt.key";

    public Property[] getLocalProperties();

};