package com.brightoil.marineonline.gateway.base.apigateway.service;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

public interface AnonTokenService {

    public void createGuestToken(String reqId, Handler<AsyncResult<String>> completer);

}