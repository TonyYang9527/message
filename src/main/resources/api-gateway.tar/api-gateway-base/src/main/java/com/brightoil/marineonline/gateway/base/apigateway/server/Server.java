package com.brightoil.marineonline.gateway.base.apigateway.server;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

public interface Server {
    void start(Handler<AsyncResult<Void>> completer);
    void stop(Handler<AsyncResult<Void>> completer);
}
