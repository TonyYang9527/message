package com.brightoil.marineonline.gateway.base.apigateway.service;

public interface UUIDService {
    public int getUniqueIntId();
    public String getUniqueRequestId();
    public String getUniqueRequestId(String key);
}
