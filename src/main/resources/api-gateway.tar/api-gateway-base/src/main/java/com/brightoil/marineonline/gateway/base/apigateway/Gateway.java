package com.brightoil.marineonline.gateway.base.apigateway;

import com.brightoil.marineonline.gateway.base.apigateway.server.ServerService;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.util.ServiceRepo;
import io.vertx.core.Future;
import io.vertx.reactivex.core.AbstractVerticle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Gateway extends AbstractVerticle {

    private static final Logger logger = LoggerFactory.getLogger(Gateway.class);

    public static final int       AddressResolverOptions_CacheMaxTimeToLive = 0;
    public static final int       AddressResolverOptions_CacheNegativeTimeToLive = 0;
    public static final int       AddressResolverOptions_MaxQueries = 4;
    public static final long      AddressResolverOptions_QueryTimeout = 5000;

    public static final boolean   HttpServerOptions_CompressionSupported = true;
    public static final boolean   HttpServerOptions_LogActivity = false;
    public static final boolean   HttpServerOptions_TcpKeepAlive = false;
    public static final int       HttpServerOptions_IdleTimeout = 120; // 35 seconds considered time to live for web socket, 300 seconds for testing

    public static final boolean   HttpClientOptions_TryUseCompression = true;
    public static final boolean   HttpClientOptions_LogActivity = false;
    public static final boolean   HttpClientOptions_TcpKeepAlive = false;
    public static final boolean   HttpClientOptions_KeepAlive = false;
    public static final int       HttpClientOptions_MaxPoolSize = 1;
    public static final int       HttpClientOptions_IdleTimeout = 120;

    private ServerService serverService;

    @Override
    public void start(Future<Void> startFuture) {
        logger.info("deploy verticle now");
        serverService = (ServerService) ServiceRepo.get(ServerService.class);
        serverService.start(event -> {
            if(event.cause() != null){
                logger.info("deploy verticle failed due to {}", event.cause().getMessage());
                return;
            }
            if(!event.succeeded()){
                logger.info("deploy verticle unsuccessful");
                return;
            }
            logger.info("deploy verticle succeed");
        });
    }

    @Override
    public void stop(Future<Void> stopFuture) {
        serverService.stop(stopFuture.completer());
    }
}
