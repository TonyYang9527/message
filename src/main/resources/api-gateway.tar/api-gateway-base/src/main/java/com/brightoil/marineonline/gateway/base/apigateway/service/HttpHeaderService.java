package com.brightoil.marineonline.gateway.base.apigateway.service;

import io.vertx.reactivex.core.MultiMap;
import io.vertx.reactivex.core.http.HttpServerResponse;
import io.vertx.reactivex.ext.web.RoutingContext;
import io.vertx.reactivex.ext.web.handler.sockjs.SockJSSocket;

public interface HttpHeaderService {

    public String getRemoteHost(RoutingContext ctx);

    public String getRemoteHost(SockJSSocket ctx);

    public void copyErrorResponseHeader(HttpServerResponse res);

    public void copyRequestHeader(String reqId, String anonToken, MultiMap copyFROM, MultiMap copyTO);

    public void copyResponseHeader(String reqId, String anonToken, MultiMap copyFROM, MultiMap copyTO, boolean all);

    public void allowResponseHeader(String reqId, MultiMap copyTO);

    public void allowResponseHeader(String reqId, MultiMap copyFROM, MultiMap copyTO);

}
