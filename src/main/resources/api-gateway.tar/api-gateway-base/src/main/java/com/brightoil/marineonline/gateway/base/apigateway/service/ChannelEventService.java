package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.model.EventType;
import io.vertx.core.json.JsonObject;

public interface ChannelEventService {

    void handleChannelEvent(EventType eventType, JsonObject data);
}
