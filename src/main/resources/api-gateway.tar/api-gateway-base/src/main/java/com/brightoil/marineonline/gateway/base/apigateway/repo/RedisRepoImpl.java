package com.brightoil.marineonline.gateway.base.apigateway.repo;

import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigService;
import com.brightoil.marineonline.gateway.base.apigateway.service.Config;
import com.brightoil.marineonline.gateway.base.apigateway.service.ConfigService;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import io.lettuce.core.ClientOptions;
import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.SocketOptions;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.codec.Utf8StringCodec;
import io.lettuce.core.pubsub.StatefulRedisPubSubConnection;
import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import org.slf4j.Logger;

import java.time.Duration;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;

@Singleton
public class RedisRepoImpl implements RedisRepo {

    @InjectLogger
    private Logger logger;

    @Inject
    private ConfigService configService;

    public void setConfigService(ConfigService configService) {
        this.configService = configService;
    }
    public void setLogger(Logger logger) {
        this.logger = logger;
    }

    private String uri;
    private RedisURI redisURI;
    private Utf8StringCodec codec;
    private RedisClient redisClient;

    private StatefulRedisConnection connection;
    private StatefulRedisPubSubConnection pubConnection;

    private ConcurrentHashMap<String, ConcurrentLinkedQueue<StatefulRedisPubSubConnection>> channelListenerConnectionList = new ConcurrentHashMap<>();

    private Semaphore defSemaphore = new Semaphore(1);
    private Semaphore pubsubSemaphore = new Semaphore(1);

    public boolean init() {
        try{
            uri = getRedisURI();
            logger.info(String.format("redis connection string : %s", uri));
            if(uri == null || uri.trim().length() == 0){
                return false;
            }
            initRedisPool();
        }catch (Throwable ex){
            logger.error("init failure due to {}", ex.getMessage(), ex);
            return false;
        }
        return true;
    }

    private void initRedisPool() {
        codec = new Utf8StringCodec();
        redisURI = RedisURI.create(uri);
        redisClient = RedisClient.create();
        redisClient.setOptions(ClientOptions
                .builder()
                .autoReconnect(true)
                .pingBeforeActivateConnection(true)
                .cancelCommandsOnReconnectFailure(true)
                .disconnectedBehavior(ClientOptions.DisconnectedBehavior.REJECT_COMMANDS)
                .socketOptions(
                        SocketOptions
                                .builder()
                                .keepAlive(true)
                                .connectTimeout(Duration.ofMinutes(10).abs())
                                .build()
                ).build()
        );
    }

    private String getRedisURI() {
        String ips      = (String)configService.get(Config.REDIS_IPS);
        String ports    = (String)configService.get(Config.REDIS_PORTS);
        String masterId = (String)configService.get(Config.REDIS_MASTER_ID);
        int    database = (int)   configService.get(Config.REDIS_DATABASE);
        int    timeout  = (int)   configService.get(Config.REDIS_TIMEOUT);

        String[] iparr  = ips.split(",");
        String[] ptarr  = ports.split(",");

        int   count     = iparr.length;

        if(ptarr.length != iparr.length){
            throw new RuntimeException("redis ports and ip address mapping are not match");
        }
        StringBuilder builder = new StringBuilder();
        builder.append("redis-sentinel://");
        for(int i = 0 ;  i < count ; i++){
            String  host = iparr[i];
            Integer port = Integer.parseInt(ptarr[i].trim());
            if(i > 0){
                builder.append(",");
            }
            if(host != null && port != null && host.trim().length() > 0 && port.intValue() > 0){
                builder.append(host).append(":").append(port);
            }
        }

        if(database > 0){
            builder.append("/").append(database);
        }
        boolean hasParam = false;
        if(timeout > 0){
            builder.append("?");
            builder.append("timeout=").append(timeout).append("s");
            hasParam = true;
        }
        if(hasParam){
            builder.append("&");
        }else {
            builder.append("?");
        }

        if(masterId != null && masterId.trim().length() > 0){
            builder.append("sentinelMasterId=").append(masterId);
        }

        return builder.toString();
    }

    @Override
    public void getConnection(Handler<AsyncResult<StatefulRedisConnection>> completer) {
        if(connection != null && connection.isOpen()){
            completer.handle(Future.succeededFuture(connection));
            return;
        }
        if(!defSemaphore.tryAcquire()){
            repeatingGetConnection(completer);
            return;
        }
        redisClient.connectAsync(codec, redisURI).handleAsync((conn, throwable) -> {
            defSemaphore.release(1);
            if(throwable != null){
                logger.error("retrieve redis default connection failed due to {}", throwable.getMessage(), throwable);
                repeatingGetConnection(completer);
                return null;
            }
            if(!(conn != null && conn.isOpen())){
                logger.error("retrieve redis default connection unsuccessful due to {}", throwable.getMessage(), throwable);
                repeatingGetConnection(completer);
                return null;
            }
            if(!(connection != null && connection.isOpen())){
                connection = conn;
            }
            completer.handle(Future.succeededFuture(connection));
            return null;
        });
    }

    private void repeatingGetConnection(Handler<AsyncResult<StatefulRedisConnection>> completer) {
        VertxHolder.get().setTimer(100, event -> {
            getConnection(completer);
        });
    }

    @Override
    public void getPubConnection(Handler<AsyncResult<StatefulRedisPubSubConnection>> completer) {
        if(pubConnection != null && pubConnection.isOpen()){
            completer.handle(Future.succeededFuture(pubConnection));
            return;
        }
        if(!pubsubSemaphore.tryAcquire()){
            repeatingGetPubConnection(completer);
            return;
        }
        redisClient.connectPubSubAsync(codec, redisURI).handleAsync((conn, throwable) -> {
            pubsubSemaphore.release(1);
            if(throwable != null){
                logger.error("retrieve redis publish connection failed due to {}", throwable.getMessage(), throwable);
                repeatingGetPubConnection(completer);
                return null;
            }
            if(!(conn != null && conn.isOpen())){
                logger.error("retrieve redis publish connection unsuccessful due to {}", throwable.getMessage(), throwable);
                repeatingGetPubConnection(completer);
                return null;
            }
            if(!(pubConnection != null && pubConnection.isOpen())){
                pubConnection = conn;
            }
            completer.handle(Future.succeededFuture(pubConnection));
            return null;
        });
    }

    private void repeatingGetPubConnection(Handler<AsyncResult<StatefulRedisPubSubConnection>> completer) {
        VertxHolder.get().setTimer(100, event -> {
            getPubConnection(completer);
        });
    }

    @Override
    public void getSubConnection(String channel, Handler<AsyncResult<StatefulRedisPubSubConnection>> completer) {
        redisClient.connectPubSubAsync(codec, redisURI).handleAsync((conn, throwable) -> {
            if(throwable != null){
                logger.error("retrieve redis subscription connection failed due to {}", throwable.getMessage(), throwable);
                repeatingGetSubConnection(channel, completer);
                return null;
            }
            if(!(conn != null && conn.isOpen())){
                logger.error("retrieve redis subscription connection unsuccessful due to {}", throwable.getMessage(), throwable);
                repeatingGetSubConnection(channel, completer);
                return null;
            }
            completer.handle(Future.succeededFuture(conn));
            return null;
        });
    }

    private void repeatingGetSubConnection(String channel, Handler<AsyncResult<StatefulRedisPubSubConnection>> completer) {
        VertxHolder.get().setTimer(100, event -> {
            getSubConnection(channel, completer);
        });
    }

    @Override
    public void releaseConnection(final StatefulRedisConnection connection) {}

    @Override
    public void releasePubConnection(StatefulRedisPubSubConnection connection) {}

    @Override
    public void releaseSubConnection(String channel, StatefulRedisPubSubConnection connection) {
        ConcurrentLinkedQueue<StatefulRedisPubSubConnection> list = channelListenerConnectionList.get(channel);
        if(list == null){
            list = new ConcurrentLinkedQueue<>();
        }
        list.add(connection);
        channelListenerConnectionList.put(channel, list);
    }

    @Override
    public void obtainSubConnections(String channel, Handler<AsyncResult<ConcurrentLinkedQueue<StatefulRedisPubSubConnection>>> completer) {
        ConcurrentLinkedQueue<StatefulRedisPubSubConnection> list = channelListenerConnectionList.get(channel);
        if(list != null){
            completer.handle(Future.succeededFuture(list));
            return;
        }
        completer.handle(Future.succeededFuture());
    }

    @Override
    public void closeSubConnections(String channel, Handler<AsyncResult<Void>> completer) {
        try{
            ConcurrentLinkedQueue<StatefulRedisPubSubConnection> list = channelListenerConnectionList.get(channel);
            if(list != null) {
                list.iterator().forEachRemaining(conn -> {
                    try {
                        conn.close();
                    } catch (Throwable ex) {
                    }
                });
                list.clear();
            }
            completer.handle(Future.succeededFuture());
        }catch (Throwable e){
            completer.handle(Future.succeededFuture());
        }
    }
}
