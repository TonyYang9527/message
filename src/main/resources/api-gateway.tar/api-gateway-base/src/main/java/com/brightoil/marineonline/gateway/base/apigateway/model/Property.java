package com.brightoil.marineonline.gateway.base.apigateway.model;

public class Property {

    private String      name;
    private ConfigType type;

    public static Property create(String name, ConfigType type){
        return new Property(name, type);
    }

    public Property(String name, ConfigType type){
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public ConfigType getType() {
        return type;
    }
}
