package com.brightoil.marineonline.gateway.base.apigateway;

import com.brightoil.marineonline.gateway.base.apigateway.server.Server;
import com.brightoil.marineonline.gateway.base.apigateway.service.InitializationService;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.VertxHolder;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.util.ServiceRepo;
import com.brightoil.marineonline.gateway.base.guicetools.logger.LogRepository;
import com.brightoil.marineonline.gateway.base.guicetools.logger.LoggerModuler;
import com.brightoil.marineonline.gateway.base.guicetools.scan.Component;
import com.brightoil.marineonline.gateway.base.guicetools.scan.ComponentScanModule;
import com.brightoil.marineonline.gateway.base.guicetools.util.ComponentScanUtil;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Singleton;
import io.vertx.core.DeploymentOptions;
import io.vertx.core.Future;
import io.vertx.core.VertxOptions;
import io.vertx.core.dns.AddressResolverOptions;
import io.vertx.reactivex.core.Vertx;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class Starter {

    private static final Logger logger = LoggerFactory.getLogger(Starter.class);

    public void bootstrap() {
        // scan all components
        configComponents();
        configVertx();
        // load all modules
        if(!configModules()){
            return;
        }
        initService();
        configListener();
    }

    private void initService() {
        InitializationService initSrv = (InitializationService) ServiceRepo.get(InitializationService.class);
        initSrv.init();
    }

    private void configListener() {
        Server server = (Server)ServiceRepo.get(Server.class);
        Future<Void> future = Future.future();
        future.setHandler(event -> {
            deploy();
        });
        server.start(future);
    }

    private void deploy() {
        DeploymentOptions deploymentOptions = configDeploymentOptions();
        VertxHolder.get().deployVerticle(Gateway.class.getName(), deploymentOptions);
    }

    private boolean configModules() {
        // logger module
        LoggerModuler logModule = new LoggerModuler();
        // package scan module
        ComponentScanModule scanModule = new ComponentScanModule("com.brightoil.marineonline", Singleton.class, Component.class);
        // initialization module
        //InitializationModule initModule = new InitializationModule(Arrays.asList());
        // create injector
        Injector injector = Guice.createInjector(logModule, scanModule);
        // get vertx service
        List<String> failedServiceList = scanModule.getFailed();
        if(failedServiceList.size() > 0){
            for (String service : failedServiceList) {
                logger.error("Gateway initialization finished with failure on {}", service);
            }
            return false;
        }else{
            ServiceRepo.set(injector);
            LogRepository.view(logger);
            logger.info("Gateway initialization finished successfully.");
            return true;
        }
    }

    private void configComponents() {
        ComponentScanUtil.configure("com.brightoil.marineonline", Singleton.class, Component.class);
    }

    private DeploymentOptions configDeploymentOptions() {
        DeploymentOptions deploymentOptions = new DeploymentOptions();
        deploymentOptions.setInstances(5);
        return deploymentOptions;
    }

    private void configVertx() {
        // prepare address resolver options
        AddressResolverOptions addressResolverOptions = configAddressResolverOptions();
        VertxOptions vertxOptions = configVertxOptions(addressResolverOptions);
        Vertx vertx = Vertx.vertx(vertxOptions);
        VertxHolder.set(vertx);
    }

    private VertxOptions configVertxOptions(AddressResolverOptions addressResolverOptions) {
        int process = Runtime.getRuntime().availableProcessors();
        logger.info("available processor is {}", process);
        VertxOptions vertxOptions = null;
        vertxOptions = new VertxOptions();
        vertxOptions.setEventLoopPoolSize(15);
        vertxOptions.setWorkerPoolSize(60);
        vertxOptions.setAddressResolverOptions(addressResolverOptions);
        return vertxOptions;
    }

    private AddressResolverOptions configAddressResolverOptions() {
        AddressResolverOptions addressResolverOptions = null;
        addressResolverOptions = new AddressResolverOptions();
        addressResolverOptions.setCacheMaxTimeToLive(Gateway.AddressResolverOptions_CacheMaxTimeToLive);
        addressResolverOptions.setCacheNegativeTimeToLive(Gateway.AddressResolverOptions_CacheNegativeTimeToLive);
        addressResolverOptions.setMaxQueries(Gateway.AddressResolverOptions_MaxQueries);
        addressResolverOptions.setQueryTimeout(Gateway.AddressResolverOptions_QueryTimeout);
        return addressResolverOptions;
    }
}
