package com.brightoil.marineonline.gateway.base.apigateway.common;

import io.netty.handler.codec.http.HttpHeaderNames;

public class Constants {

    public static final long   DEF_TIMER_TIME  = 3500;
    public static final int    DEF_APP_PORT    = 80;

    public static final String CONFIG_SECRET   = "secret";
    public static final String JWT_TOKEN_GUEST = "isGuest";

    public static final String HEADER_PROPERTY_HTTP_GATEWAY = "bmo-gateway";
    public static final String HEADER_PROPERTY_HTTP_REQUEST_KEY = "bmo-request-key";
    public static final String HEADER_PROPERTY_HTTP_USER_TOKEN = HttpHeaderNames.AUTHORIZATION.toString();

    public static final String EVENT_PARAM_BLACKLIST_HOST_ADDR  = "HOST_ADDR";
    public static final String EVENT_PARAM_BLACKLIST_ACTION     = "ACTION";
    public static final String EVENT_PARAM_BLACKLIST_ACTION_ADD = "Add";
    public static final String EVENT_PARAM_BLACKLIST_ACTION_RM  = "Remove";

    public static final String EVENT_PARAM_LOGGING_CLASS_NAME  = "CLASS_NAME";
    public static final String EVENT_PARAM_LOGGING_LEVEL       = "LOGGER_LEVEL";

}
