package com.brightoil.marineonline.gateway.base.apigateway.service;

import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.HostAddrHolder;
import com.brightoil.marineonline.gateway.base.apigateway.utilities.holder.HostAddrHolder;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.logger.InjectLogger;
import com.brightoil.marineonline.gateway.base.guicetools.scan.Order;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import org.slf4j.Logger;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;

@Singleton
@Order(1)
public class HostServiceImpl implements HostService {

    @InjectLogger
    private Logger logger;

    @Inject
    private ConfigService configService;

    private String host;
    private String hostName;
    private String hostAddr;

    public boolean init(){
        try{
            int port = (int)configService.get(Config.SERVER_PORT);
            InetAddress vhost = null;
            try {
                vhost = Inet4Address.getLocalHost();
                hostAddr = vhost.getHostAddress();
                hostName = vhost.getHostName();
                host = String.format("%s:%s", hostAddr, port);
                HostAddrHolder.setAddr(hostAddr);
                HostAddrHolder.setName(hostName);
                HostAddrHolder.setHost(host);
                return true;
            } catch (UnknownHostException e) {
                logger.error("init server host failure", e);
            }
        }catch (Throwable ex){
            logger.error("init failure due to {}", ex.getMessage(), ex);
            return false;
        }
        return false;
    }

    @Override
    public String getHost() {
        return host;
    }

    public String getHostAddr(){
        return hostAddr;
    }

    public String getHostName() {
        return hostName;
    }
}
